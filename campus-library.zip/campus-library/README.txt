Campus Library - CS543 GraphQL tutorial

Quick start (Windows):
  1. Install Node.js (v18+) and MySQL Community Server.
  2. Double-click run.bat and enter your MySQL root password.
     It creates the database, installs packages, starts the API and opens the page.

Manual way:
  mysql -u root -p < schema.sql
  npm install @apollo/server graphql mysql2
  set MYSQL_PASSWORD=yourpassword     (or edit db.js)
  node server.js
  then open public/index.html (Live Server or double-click)
