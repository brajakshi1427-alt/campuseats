// db.js -- one shared connection pool to MySQL
// run.bat passes your password via the MYSQL_PASSWORD environment variable.
// If you run "node server.js" by hand, either set that variable or type the password below.
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: process.env.MYSQL_PASSWORD || '',   // <-- or put your password here
  database: 'gqldemo',
});

module.exports = pool;
