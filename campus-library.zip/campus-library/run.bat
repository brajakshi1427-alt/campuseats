@echo off
setlocal
cd /d "%~dp0"
title Campus Library - setup
echo ==== Campus Library: HTML/CSS - GraphQL - MySQL ====
echo.

rem --- 1. check Node.js
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install it from https://nodejs.org and run this file again.
  pause
  exit /b 1
)

rem --- 2. find MySQL (add the usual install folders to PATH)
for /d %%D in ("C:\Program Files\MySQL\MySQL Server *") do set "PATH=%PATH%;%%D\bin"
where mysql >nul 2>nul
if errorlevel 1 (
  echo [ERROR] mysql command not found. Install MySQL Community Server and run this file again.
  pause
  exit /b 1
)

rem --- 3. ask for the root password
set /p "PW=Enter your MySQL root password (press Enter if none): "
set "MYSQL_PWD=%PW%"
set "MYSQL_PASSWORD=%PW%"

mysql -u root -e "SELECT 1" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Could not log in to MySQL as root. Check the password and that the MySQL service is running.
  pause
  exit /b 1
)

rem --- 4. create the database only if it does not exist yet
mysql -u root -N -e "SHOW DATABASES LIKE 'gqldemo'" | find "gqldemo" >nul
if errorlevel 1 (
  echo Creating database gqldemo from schema.sql ...
  mysql -u root < schema.sql
  if errorlevel 1 (
    echo [ERROR] schema.sql failed.
    pause
    exit /b 1
  )
) else (
  echo Database gqldemo already exists - skipping schema.sql.
)

rem --- 5. install the Node libraries the first time
if not exist node_modules (
  echo Installing npm packages - needs internet, first run only ...
  call npm install @apollo/server graphql mysql2
  if errorlevel 1 (
    echo [ERROR] npm install failed.
    pause
    exit /b 1
  )
)

rem --- 6. start the API in its own window, then open the page
echo Starting GraphQL API on http://localhost:4000/ ...
start "GraphQL API (close this window to stop)" cmd /k node server.js
timeout /t 4 /nobreak >nul
start "" "%~dp0public\index.html"

echo.
echo Done. The page is open in your browser.
echo Apollo Sandbox for testing queries: http://localhost:4000/
echo To stop, close the "GraphQL API" window.
pause
