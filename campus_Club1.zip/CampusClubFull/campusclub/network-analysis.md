# Network Analysis

(Fill this in from the browser, or create it with `python tools/analyze_har.py your-file.har https://your-site`.)

**Website:** https://
**Date / browser:**

| Item | Result |
|---|---|
| Number of requests | |
| Total page size (transferred) | |
| Slowest resource (name, type, time) | |
| 3xx / 4xx responses seen | |

Observation (one or two sentences):

![Network waterfall](docs/network.png)
