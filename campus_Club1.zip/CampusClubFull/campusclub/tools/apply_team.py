"""apply_team.py - stamps YOUR team id, names and service owners into every document.

1. Edit tools/team.json (team id, roll numbers, names, which member owns which service).
2. From the repository root run:   python tools/apply_team.py
It (re)creates: assignment2/design.pdf, services.png, services.drawio, schema.png,
schema.drawio, schema.sql (also copied to backend/db/schema.sql), assignment3/integration.pdf,
and fills the team block in every README.md / NOTES.md that has <!--TEAM--> markers.
Needs:  pip install reportlab matplotlib pillow
"""
import glob
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import docgen  # noqa: E402

team = docgen.load_team(os.path.join(HERE, "team.json"))
a2 = os.path.join(ROOT, "assignment2")
a3 = os.path.join(ROOT, "assignment3")
os.makedirs(a2, exist_ok=True)
os.makedirs(a3, exist_ok=True)

docgen.build_sql(os.path.join(a2, "schema.sql"))
docgen.build_services_png(team, os.path.join(a2, "services.png"))
docgen.build_services_drawio(team, os.path.join(a2, "services.drawio"))
docgen.build_schema_png(os.path.join(a2, "schema.png"))
docgen.build_schema_drawio(os.path.join(a2, "schema.drawio"))
docgen.build_design_pdf(team, os.path.join(a2, "design.pdf"), os.path.join(a2, "services.png"))
docgen.build_integration_pdf(team, os.path.join(a3, "integration.pdf"), os.path.join(a3, "soap-request.xml"))
os.makedirs(os.path.join(ROOT, "backend", "db"), exist_ok=True)
shutil.copyfile(os.path.join(a2, "schema.sql"), os.path.join(ROOT, "backend", "db", "schema.sql"))
print("assignment2: design.pdf, services.drawio/png, schema.drawio/png, schema.sql (+ backend/db/schema.sql)")
print("assignment3: integration.pdf")

filled = []
for path in glob.glob(os.path.join(ROOT, "**", "*.md"), recursive=True):
    if "node_modules" in path.split(os.sep):
        continue
    if docgen.fill_markdown(path, team):
        filled.append(os.path.relpath(path, ROOT))
print("Team block filled in:", ", ".join(filled) if filled else "(no markdown files had markers)")

if team["team_id"] == "TEAM-00" or any(m["name"].startswith("Member ") for m in team["members"]):
    print("\nWARNING: tools/team.json still has placeholder names. Edit it and run this script again.")
