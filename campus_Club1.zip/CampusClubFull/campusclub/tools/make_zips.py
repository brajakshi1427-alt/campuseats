"""make_zips.py - builds the zip files you upload (the Team Leader uploads them).

   python tools/make_zips.py          (run from the repository root, after the evidence files exist)
Creates zips/ with:
  Assignment3_CampusClub.zip   exactly the five files Assignment 3 asks for
  Assignment4.zip, Assignment5.zip, Assignment6.zip   the assignment folder + backend/ (no node_modules)
  Assignment1.zip, Assignment2.zip
"""
import os
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "zips")
os.makedirs(OUT, exist_ok=True)
SKIP = {"node_modules", "__pycache__", ".git", "zips", "dist", ".env"}


def add_tree(z, folder):
    n = 0
    for base, dirs, files in os.walk(os.path.join(ROOT, folder)):
        dirs[:] = [d for d in dirs if d not in SKIP]
        for f in files:
            if f in SKIP:
                continue
            full = os.path.join(base, f)
            z.write(full, os.path.relpath(full, ROOT))
            n += 1
    return n


def make(name, folders, files=()):
    with zipfile.ZipFile(os.path.join(OUT, name), "w", zipfile.ZIP_DEFLATED) as z:
        n = sum(add_tree(z, f) for f in folders)
        for f in files:
            if os.path.exists(os.path.join(ROOT, f)):
                z.write(os.path.join(ROOT, f), f)
                n += 1
    print(f"{name}: {n} files")


make("Assignment1.zip", ["docs"], ["README.md", "brief.md", "http-log.md", "network-analysis.md"])
make("Assignment2.zip", ["assignment2"])
with zipfile.ZipFile(os.path.join(OUT, "Assignment3_CampusClub.zip"), "w", zipfile.ZIP_DEFLATED) as z:
    for f in ["integration.pdf", "partner.wsdl", "soap-request.xml", "soap-response.xml", "soap-fault.xml"]:
        z.write(os.path.join(ROOT, "assignment3", f), f)
print("Assignment3_CampusClub.zip: 5 files")
for a in (4, 5, 6):
    make(f"Assignment{a}.zip", [f"assignment{a}", "backend", "frontend"], ["README.md"])
