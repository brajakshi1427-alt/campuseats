"""make_http_log.py - runs five REAL curl -i requests against a public read-only JSON API
and writes http-log.md (request, response, and a one-line note on each status / Content-Type).

  python tools/make_http_log.py                      (uses jsonplaceholder.typicode.com)
  python tools/make_http_log.py https://other.api    (use another API base URL)

Needs: curl (built into Windows 10/11, Mac and Linux) and an internet connection.
"""
import re
import shutil
import subprocess
import sys
from datetime import datetime

BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "https://jsonplaceholder.typicode.com"
CURL = shutil.which("curl.exe") or shutil.which("curl") or "curl"
MAX_BODY_LINES = 18

CALLS = [
    ("Read one resource", "/posts/1",
     "Asks for a single post by id."),
    ("Read a filtered collection (query string)", "/posts?userId=1",
     "The query string ?userId=1 filters the list; it is still a plain read."),
    ("Read a different resource", "/users/1",
     "Same pattern on another noun (users)."),
    ("Read a nested resource", "/posts/1/comments",
     "Comments are a sub-resource of post 1."),
    ("Deliberate failure: ask for something that does not exist", "/posts/99999",
     "There is no post 99999, so the server must answer with an error status."),
]

STATUS = {
    200: "200 OK - the request worked and the body holds what was asked for.",
    201: "201 Created - a new resource was made.",
    204: "204 No Content - it worked and there is no body.",
    301: "301 Moved Permanently - the resource has a new URL (see Location).",
    304: "304 Not Modified - the cached copy is still valid.",
    400: "400 Bad Request - the server could not understand the request.",
    401: "401 Unauthorized - credentials are missing or wrong.",
    403: "403 Forbidden - understood, but not allowed.",
    404: "404 Not Found - the server understood the request but nothing exists at that URL.",
    500: "500 Internal Server Error - the server failed while handling a valid request.",
}
CTYPE = {
    "application/json": "application/json - the body is JSON text that a program should parse as data.",
    "text/html": "text/html - the body is a web page meant for a browser.",
    "text/plain": "text/plain - the body is plain text.",
    "application/xml": "application/xml - the body is XML.",
}


def run(path):
    url = BASE + path
    res = subprocess.run([CURL, "-s", "-i", "-v", url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = res.stdout.decode("utf-8", "replace").replace("\r\n", "\n")
    err = res.stderr.decode("utf-8", "replace").replace("\r\n", "\n")
    request_lines = []
    for line in err.split("\n"):
        if line.startswith(">"):
            request_lines.append(line[1:].lstrip(" ") if line != ">" else "")
    head, _, body = out.partition("\n\n")
    return url, "\n".join(request_lines).strip(), head.strip(), body.strip()


def main():
    parts = [f"# HTTP Log\n\nAPI used: `{BASE}` (public, read-only JSON API).  Tool: `curl -i`.  "
             f"Captured: {datetime.now():%Y-%m-%d %H:%M}.\n"]
    for n, (title, path, what) in enumerate(CALLS, 1):
        url, request, head, body = run(path)
        if not head:
            sys.exit(f"No response from {url}. Check your internet connection and that curl works: curl -i {url}")
        m = re.match(r"HTTP/\S+\s+(\d{3})", head)
        code = int(m.group(1)) if m else 0
        ctype = ""
        for line in head.split("\n"):
            if line.lower().startswith("content-type:"):
                ctype = line.split(":", 1)[1].strip().split(";")[0].strip().lower()
        lines = body.split("\n")
        shown = "\n".join(lines[:MAX_BODY_LINES]) + ("\n... (truncated)" if len(lines) > MAX_BODY_LINES else "")
        parts.append(
            f"\n## {n}. {title}\n\n{what}\n\n**Command:** `curl -i {url}`\n\n"
            f"**Request**\n```\n{request}\n```\n\n**Response**\n```\n{head}\n\n{shown}\n```\n\n"
            f"**Notes**\n- Status: {STATUS.get(code, str(code) + ' - see the HTTP status code registry.')}\n"
            f"- Content-Type: {CTYPE.get(ctype, (ctype or 'none') + ' - the media type of the body.')}\n")
        print(f"done {n}/5: {path} -> {code}")
    with open("http-log.md", "w", encoding="utf-8") as fh:
        fh.write("\n".join(parts))
    print("Saved http-log.md (in the folder you ran this from)")


if __name__ == "__main__":
    main()
