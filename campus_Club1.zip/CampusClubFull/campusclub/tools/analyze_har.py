"""analyze_har.py - turns a browser HAR export into network-analysis.md.

How to get the HAR file (Chrome / Edge):
  1. Open the website, press F12, open the Network tab, tick "Disable cache".
  2. Reload the page (Ctrl + R) and wait until it finishes.
  3. Right-click inside the request list -> "Save all as HAR with content" -> save it here.
  4. Take a screenshot of the waterfall and save it as docs/network.png.
Then:   python tools/analyze_har.py yoursite.har https://yoursite.example
"""
import json
import sys
from datetime import datetime

if len(sys.argv) < 2:
    sys.exit(__doc__)
har_path = sys.argv[1]
site = sys.argv[2] if len(sys.argv) > 2 else "(write the site address here)"

with open(har_path, encoding="utf-8") as fh:
    entries = json.load(fh)["log"]["entries"]


def size(e):
    r = e["response"]
    transferred = r.get("_transferSize")
    if isinstance(transferred, (int, float)) and transferred >= 0:
        return int(transferred)
    parts = [x for x in (r.get("headersSize", 0), r.get("bodySize", 0)) if isinstance(x, (int, float)) and x > 0]
    return int(sum(parts)) or int(r.get("content", {}).get("size", 0) or 0)


def human(n):
    return f"{n / 1024 / 1024:.2f} MB" if n >= 1024 * 1024 else f"{n / 1024:.1f} KB"


def short(url, width=70):
    return url if len(url) <= width else url[:width - 3] + "..."


total = sum(size(e) for e in entries)
by_time = sorted(entries, key=lambda e: e.get("time", 0), reverse=True)
slow = by_time[0]
redirects = [e for e in entries if 300 <= e["response"]["status"] < 400]
errors = [e for e in entries if 400 <= e["response"]["status"] < 600]


def kind(e):
    return (e["response"].get("content", {}).get("mimeType") or "unknown").split(";")[0]


lines = [
    "# Network Analysis", "",
    f"**Website:** {site}",
    f"**Captured:** {datetime.now():%Y-%m-%d %H:%M} (browser DevTools, Network tab, Disable cache ticked)", "",
    "| Item | Result |", "|---|---|",
    f"| Number of requests | {len(entries)} |",
    f"| Total page size (transferred) | {human(total)} |",
    f"| Slowest resource | {short(slow['request']['url'])} ({kind(slow)}, {slow.get('time', 0):.0f} ms) |",
    f"| 3xx responses | {len(redirects)} |",
    f"| 4xx / 5xx responses | {len(errors)} |", "",
    "## Five slowest resources", "", "| # | Resource | Type | Time |", "|---|---|---|---|",
]
for i, e in enumerate(by_time[:5], 1):
    lines.append(f"| {i} | {short(e['request']['url'])} | {kind(e)} | {e.get('time', 0):.0f} ms |")
lines += ["", "## 3xx and 4xx responses", ""]
if redirects or errors:
    lines += ["| Status | URL |", "|---|---|"]
    for e in redirects + errors:
        lines.append(f"| {e['response']['status']} {e['response'].get('statusText', '')} | {short(e['request']['url'], 90)} |")
else:
    lines.append("None seen.")
lines += ["", "## Observation", "",
          f"The page needed {len(entries)} requests and about {human(total)}; the slowest item was "
          f"`{short(slow['request']['url'], 50)}`. (Add one or two sentences of your own: what took the time, "
          "and why you think so.)", "", "![Network waterfall](docs/network.png)", ""]
with open("network-analysis.md", "w", encoding="utf-8") as fh:
    fh.write("\n".join(lines))
print(f"Saved network-analysis.md  ({len(entries)} requests, {human(total)})")
