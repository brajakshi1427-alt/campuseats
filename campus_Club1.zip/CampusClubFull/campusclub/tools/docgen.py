"""docgen.py - builds the Assignment 2 and 3 documents, diagrams and schema from
team.json, so every file carries YOUR team id, names and service owners.

Needs:  pip install reportlab matplotlib
Used by apply_team.py (run:  python apply_team.py)
"""
import json
import os
import re
from xml.sax.saxutils import escape, quoteattr

HERE = os.path.dirname(os.path.abspath(__file__))

# ----------------------------------------------------------------------------
# The design (one source of truth for diagrams, PDFs and SQL)
# ----------------------------------------------------------------------------
COLORS = {"Clubs": "#dbeafe", "Events": "#fde68a", "Registrations": "#bbf7d0", "Notifications": "#fbcfe8"}
EDGE = {"Clubs": "#1d4ed8", "Events": "#b45309", "Registrations": "#15803d", "Notifications": "#be185d"}
PROJECT = "CampusClub"

OWNS = {
    "Clubs": ["Clubs (name, category, description)", "Club members and their roles"],
    "Events": ["Events (title, venue, time, capacity)", "Event status (open / cancelled)"],
    "Registrations": ["Registrations (ticket, status, note)", "Attendance (check-in records)"],
    "Notifications": ["Notification log (masked recipient, message, status)"],
}

# (caller, callee, operation)
CALLS = [
    ("Registrations", "Events", "getEvent"),
    ("Registrations", "Notifications", "sendNotification"),
    ("Events", "Clubs", "checkClub"),
]

CAPABILITIES = [
    ("Create a club and describe it", "Clubs"),
    ("Browse and search clubs", "Clubs"),
    ("Join and leave a club", "Clubs"),
    ("See who the members of a club are", "Clubs"),
    ("Create and update an event for a club", "Events"),
    ("Browse upcoming events", "Events"),
    ("Cancel an event", "Events"),
    ("Register for an event and get a ticket", "Registrations"),
    ("Cancel a registration", "Registrations"),
    ("Check a student in at the event (attendance)", "Registrations"),
    ("Track registrations and attendance of an event", "Registrations"),
    ("Send a confirmation or reminder message", "Notifications"),
]

CONTRACTS = {
    "Clubs": [
        ("listClubs", "optional category; search text; page size and position", "one page of clubs with member counts, and the total", "invalid-query"),
        ("getClub", "club", "name, description, category, president, member count", "club-not-found"),
        ("createClub", "name; optional description and category (organizers and admins)", "the new club", "validation-failed; forbidden"),
        ("joinClub", "club (the member is the caller)", "membership confirmation", "club-not-found; already-member"),
        ("leaveClub", "club (the member is the caller)", "nothing", "club-not-found; membership-not-found"),
        ("listMembers", "club; page (organizers, admins, services)", "one page of members and the total", "club-not-found; forbidden"),
    ],
    "Events": [
        ("listEvents", "optional club; status; upcoming only; sort; page", "one page of events and the total", "invalid-query"),
        ("getEvent", "event", "title, venue, start and end time, capacity, status, whether registration is open", "event-not-found"),
        ("createEvent", "club; title; venue; start time; capacity; optional end time and description (organizers, admins)", "the new event", "validation-failed; unknown-club; clubs-unavailable; forbidden"),
        ("updateEvent", "event; changed fields; optional version check", "the updated event", "event-not-found; validation-failed; precondition-failed; illegal-transition"),
        ("cancelEvent", "event", "the event, now cancelled", "event-not-found; illegal-transition; forbidden"),
    ],
    "Registrations": [
        ("registerForEvent", "event; optional phone; optional note; idempotency key", "registration (ticket code, status, notification state)", "validation-failed; unknown-event; event-closed; event-full; already-registered; idempotency-key-reuse; events-unavailable"),
        ("getRegistration", "registration", "the registration", "registration-not-found"),
        ("listRegistrations", "optional event; status; student (organizers); sort; page", "one page of registrations and the total", "invalid-query"),
        ("cancelRegistration", "registration", "the registration, now cancelled; the seat is free again", "registration-not-found; illegal-transition"),
        ("checkIn", "registration (organizers and admins)", "the registration, now attended, with the check-in time", "registration-not-found; illegal-transition; forbidden"),
    ],
    "Notifications": [
        ("sendNotification", "recipient reference; phone; message; idempotency key", "notification record (status sent)", "validation-failed; recipient-unreachable; notifications-unavailable; forbidden"),
        ("getNotification", "notification", "the notification record", "notification-not-found"),
    ],
}

# name, type, flag  (flag: PK, FK, NULL or "")   - matches backend/lib/tables.js
TABLES = {
    "Clubs": [
        ("clubs", [("club_id", "BIGINT", "PK"), ("name", "VARCHAR(100)", ""), ("description", "VARCHAR(500)", ""), ("category", "VARCHAR(20)", ""), ("president_ref", "VARCHAR(40)", ""), ("is_active", "TINYINT(1)", ""), ("created_at", "DATETIME", "")]),
        ("club_members", [("member_id", "BIGINT", "PK"), ("club_id", "BIGINT", "FK"), ("student_ref", "VARCHAR(40)", ""), ("role", "VARCHAR(20)", ""), ("joined_at", "DATETIME", "")]),
    ],
    "Events": [
        ("events", [("event_id", "BIGINT", "PK"), ("club_ref", "BIGINT", ""), ("title", "VARCHAR(120)", ""), ("description", "VARCHAR(1000)", ""), ("venue", "VARCHAR(120)", ""), ("starts_at", "DATETIME", ""), ("ends_at", "DATETIME", "NULL"), ("capacity", "INT", ""), ("status", "VARCHAR(20)", ""), ("created_by", "VARCHAR(40)", ""), ("version", "INT", ""), ("created_at", "DATETIME", ""), ("updated_at", "DATETIME", "")]),
    ],
    "Registrations": [
        ("registrations", [("registration_id", "BIGINT", "PK"), ("event_ref", "BIGINT", ""), ("student_ref", "VARCHAR(40)", ""), ("status", "VARCHAR(20)", ""), ("ticket_code", "VARCHAR(12)", ""), ("note", "VARCHAR(200)", ""), ("idempotency_key", "VARCHAR(128)", "NULL"), ("request_hash", "CHAR(64)", ""), ("active_flag", "TINYINT", "NULL"), ("notification_status", "VARCHAR(20)", ""), ("version", "INT", ""), ("created_at", "DATETIME", ""), ("updated_at", "DATETIME", "")]),
        ("attendance", [("attendance_id", "BIGINT", "PK"), ("registration_id", "BIGINT", "FK"), ("checked_in_at", "DATETIME", ""), ("checked_in_by", "VARCHAR(40)", "")]),
    ],
    "Notifications": [
        ("notifications", [("notification_id", "BIGINT", "PK"), ("recipient_ref", "VARCHAR(40)", ""), ("channel", "VARCHAR(10)", ""), ("phone_masked", "VARCHAR(20)", ""), ("message", "VARCHAR(300)", ""), ("status", "VARCHAR(20)", ""), ("gateway_ref", "VARCHAR(60)", "NULL"), ("idempotency_key", "VARCHAR(128)", "NULL"), ("created_at", "DATETIME", ""), ("sent_at", "DATETIME", "NULL")]),
    ],
}
# (table, column, referenced table, referenced column)  - ONLY inside one service
FKS = [
    ("club_members", "club_id", "clubs", "club_id"),
    ("attendance", "registration_id", "registrations", "registration_id"),
]
EXTRAS = {
    "clubs": ["UNIQUE (name)", "CHECK (category IN ('technical','cultural','sports','literary','social','other'))"],
    "club_members": ["UNIQUE (club_id, student_ref)", "CHECK (role IN ('member','lead','president'))"],
    "events": ["CHECK (capacity BETWEEN 1 AND 1000)", "CHECK (status IN ('open','cancelled'))", "INDEX idx_events_starts (starts_at)"],
    "registrations": ["UNIQUE (student_ref, idempotency_key)",
                      "UNIQUE (event_ref, student_ref, active_flag)",
                      "CHECK (status IN ('registered','attended','cancelled'))",
                      "CHECK (notification_status IN ('skipped','sent','pending','failed'))"],
    "attendance": ["UNIQUE (registration_id)"],
    "notifications": ["UNIQUE (idempotency_key)", "CHECK (status IN ('queued','sent','failed'))"],
}
LOGICAL_REFS = ("club_ref, event_ref and student_ref are plain values that name something another service "
                "owns. They are NOT foreign keys: no table belongs to two services.")


def load_team(path=None):
    path = path or os.path.join(HERE, "team.json")
    with open(path, encoding="utf-8") as fh:
        team = json.load(fh)
    owners = {s: [] for s in OWNS}
    for m in team["members"]:
        for s in m.get("services", []):
            owners.setdefault(s, []).append(m["name"])
    team["owners"] = {s: (", ".join(v) if v else "(unassigned)") for s, v in owners.items()}
    return team


# ----------------------------------------------------------------------------
# schema.sql
# ----------------------------------------------------------------------------
def build_sql(out_path):
    fk_of = {(t, c): (rt, rc) for t, c, rt, rc in FKS}
    lines = ["-- CampusClub database schema (MySQL 8). One block per service.",
             "-- Rule: a table belongs to exactly ONE service; foreign keys never cross a service boundary.",
             "-- " + LOGICAL_REFS, "",
             "CREATE DATABASE IF NOT EXISTS campusclub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;",
             "USE campusclub;", ""]
    for service, tables in TABLES.items():
        lines += ["-- " + "=" * 70, f"-- {service} service", "-- " + "=" * 70, ""]
        for tname, cols in tables:
            body = []
            for cname, ctype, flag in cols:
                if "PK" in flag:
                    body.append(f"    {cname} {ctype} AUTO_INCREMENT PRIMARY KEY")
                else:
                    body.append(f"    {cname} {ctype} {'NULL' if 'NULL' in flag else 'NOT NULL'}")
            for cname, ctype, flag in cols:
                if "FK" in flag:
                    rt, rc = fk_of[(tname, cname)]
                    body.append(f"    FOREIGN KEY ({cname}) REFERENCES {rt}({rc})")
            body += [f"    {e}" for e in EXTRAS.get(tname, [])]
            lines.append(f"CREATE TABLE IF NOT EXISTS {tname} (")
            lines.append(",\n".join(body))
            lines += [") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;", ""]
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


# ----------------------------------------------------------------------------
# services.png / services.drawio
# ----------------------------------------------------------------------------
def _wrap(text, width):
    import textwrap
    return "\n".join(textwrap.wrap(text, width)) or text


def build_services_png(team, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch

    fig, ax = plt.subplots(figsize=(15, 9))
    ax.set_xlim(0, 120)
    ax.set_ylim(0, 76)
    ax.axis("off")
    ax.text(60, 73, f"{PROJECT} - service design benchmark   (Team {team['team_id']})",
            ha="center", va="center", fontsize=16, fontweight="bold")
    ax.text(60, 67.5, "Rules: no two services share data; every arrow is one call through a service contract;\n"
                      "ids that point into another service are plain references, never shared tables.",
            ha="center", va="center", fontsize=9.5, style="italic", color="#333")

    pos = {"Events": (2, 36, 28, 24), "Registrations": (46, 36, 28, 24),
           "Notifications": (90, 36, 28, 24), "Clubs": (2, 4, 28, 22)}
    for name, (x, y, w, h) in pos.items():
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                    fc=COLORS[name], ec=EDGE[name], lw=2.2))
        ax.text(x + w / 2, y + h - 2.4, f"{name} service", ha="center", va="center",
                fontsize=14, fontweight="bold", color=EDGE[name])
        ax.text(x + 1.5, y + h - 5.2, _wrap("Owner: " + team["owners"][name], 30), ha="left",
                va="top", fontsize=9.5, style="italic")
        owns = "Owns:\n" + "\n".join("  - " + _wrap(o, 28).replace("\n", "\n    ") for o in OWNS[name])
        ax.text(x + 1.5, y + h - 10.5, owns, ha="left", va="top", fontsize=9.5)

    def arrow(p1, p2, lx, ly, label):
        ax.annotate("", xy=p2, xytext=p1,
                    arrowprops=dict(arrowstyle="-|>", lw=1.8, color="#222", shrinkA=0, shrinkB=0))
        ax.text(lx, ly, label, ha="center", va="center", fontsize=9, fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#555", lw=0.8))

    arrow((46.4, 48), (30.4, 48), 38.2, 52, "Registrations -> Events:\ngetEvent")
    arrow((74.4, 48), (90.0, 48), 82.2, 53, "Registrations ->\nNotifications:\nsendNotification")
    arrow((16, 35.6), (16, 26.4), 28, 31, "Events -> Clubs:\ncheckClub")
    ax.text(50, 20, "How a registration flows\n"
                    "1. Registrations asks Events for the event (getEvent).\n"
                    "2. It checks the seats in its own data and saves the registration.\n"
                    "3. It asks Notifications to send a confirmation SMS (best effort).\n"
                    "Events asks Clubs (checkClub) once, when an event is created.",
            ha="left", va="center", fontsize=10, linespacing=1.6,
            bbox=dict(boxstyle="round,pad=0.6", fc="#f8fafc", ec="#94a3b8"))
    fig.savefig(out_path, dpi=130, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def _cell(cid, value, style, x, y, w, h, parent="1", vertex=True):
    return (f'<mxCell id="{cid}" value={quoteattr(value)} style="{style}" '
            f'vertex="1" parent="{parent}"><mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')


def _edge(eid, label, src, dst, style_extra=""):
    return (f'<mxCell id="{eid}" value={quoteattr(label)} style="endArrow=block;endFill=1;html=1;rounded=0;'
            f'strokeWidth=2;fontStyle=1;labelBackgroundColor=#ffffff;{style_extra}" edge="1" parent="1" '
            f'source="{src}" target="{dst}"><mxGeometry relative="1" as="geometry"/></mxCell>')


def _wrapper(name, cells):
    return ('<mxfile host="app.diagrams.net"><diagram name=' + quoteattr(name) + ' id="campuseats">'
            '<mxGraphModel dx="1400" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" '
            'arrows="1" fold="1" page="1" pageScale="1" pageWidth="1400" pageHeight="1000" math="0" shadow="0">'
            '<root><mxCell id="0"/><mxCell id="1" parent="0"/>' + "".join(cells) +
            '</root></mxGraphModel></diagram></mxfile>')


def build_services_drawio(team, out_path):
    pos = {"Events": (40, 300), "Registrations": (480, 300), "Notifications": (920, 300), "Clubs": (40, 640)}
    ids = {n: f"svc_{n.lower()}" for n in pos}
    cells = [_cell("title", f"<b>{PROJECT} - service design benchmark (Team {team['team_id']})</b>",
                   "text;html=1;align=center;verticalAlign=middle;fontSize=20;", 300, 30, 700, 40)]
    for name, (x, y) in pos.items():
        owns = "<br/>".join("- " + escape(o) for o in OWNS[name])
        label = (f"<b style='font-size:16px'>{name} service</b><br/><i>Owner: {escape(team['owners'][name])}</i>"
                 f"<br/><br/><b>Owns:</b><br/>{owns}")
        style = (f"rounded=1;whiteSpace=wrap;html=1;align=left;verticalAlign=top;spacingLeft=10;spacingTop=6;"
                 f"fillColor={COLORS[name]};strokeColor={EDGE[name]};strokeWidth=2;")
        cells.append(_cell(ids[name], label, style, x, y, 360, 230 if name != "Clubs" else 200))
    cells += [
        _edge("e1", "Registrations -> Events: getEvent", ids["Registrations"], ids["Events"],
              "exitX=0;exitY=0.4;entryX=1;entryY=0.4;"),
        _edge("e2", "Registrations -> Notifications: sendNotification", ids["Registrations"], ids["Notifications"],
              "exitX=1;exitY=0.4;entryX=0;entryY=0.4;"),
        _edge("e3", "Events -> Clubs: checkClub", ids["Events"], ids["Clubs"], "exitX=0.5;exitY=1;entryX=0.5;entryY=0;"),
        _cell("note", "Rules: no two services share data. Every arrow is a call through a service contract.",
              "text;html=1;align=left;fontSize=12;", 40, 900, 800, 30),
    ]
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(_wrapper("Services", cells))


# ----------------------------------------------------------------------------
# schema.png / schema.drawio
# ----------------------------------------------------------------------------
def _row(c):
    name, ctype, flag = c
    tag = "PK" if "PK" in flag else ("FK" if "FK" in flag else "  ")
    return tag, name, ctype


def build_schema_png(out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, Rectangle

    fig, ax = plt.subplots(figsize=(17, 9.5))
    ax.set_xlim(0, 124)
    ax.set_ylim(10, 82)
    ax.axis("off")
    ax.text(62, 79, "CampusClub - database schema (ER diagram, one group per service)",
            ha="center", fontsize=16, fontweight="bold")
    box = {}
    for i, (service, tables) in enumerate(TABLES.items()):
        gx, gw = 2 + i * 30.5, 28.5
        ax.add_patch(FancyBboxPatch((gx, 19), gw, 54, boxstyle="round,pad=0.3,rounding_size=1",
                                    fc=COLORS[service], ec=EDGE[service], lw=2, alpha=0.55))
        ax.text(gx + gw / 2, 71, f"{service} service", ha="center", fontsize=13,
                fontweight="bold", color=EDGE[service])
        y = 68
        for tname, cols in tables:
            h = 2.6 + 2.1 * len(cols)
            ax.add_patch(Rectangle((gx + 1, y - h), gw - 2, h, fc="white", ec="#222", lw=1.3))
            ax.add_patch(Rectangle((gx + 1, y - 2.6), gw - 2, 2.6, fc="#333", ec="#222"))
            ax.text(gx + gw / 2, y - 1.3, tname, ha="center", va="center", color="white",
                    fontsize=10.5, fontweight="bold", family="DejaVu Sans Mono")
            for r, c in enumerate(cols):
                tag, name, ctype = _row(c)
                ry = y - 2.6 - 1.05 - 2.1 * r
                ax.text(gx + 1.8, ry, tag, fontsize=8.5, va="center", fontweight="bold",
                        color="#b91c1c" if tag == "PK" else "#1d4ed8", family="DejaVu Sans Mono")
                ax.text(gx + 4.6, ry, name, fontsize=8.5, va="center", family="DejaVu Sans Mono")
                ax.text(gx + gw - 1.8, ry, ctype, fontsize=7.8, va="center", ha="right",
                        color="#555", family="DejaVu Sans Mono")
            box[tname] = (gx + 1, y - h, gw - 2, h)
            y -= h + 6
    for t, c, rt, rc in FKS:
        x1, y1, w1, h1 = box[t]
        x2, y2, w2, h2 = box[rt]
        ax.annotate("", xy=(x2 + w2 / 2, y2), xytext=(x1 + w1 / 2, y1 + h1),
                    arrowprops=dict(arrowstyle="-|>", lw=1.6, color="#1d4ed8"))
        ax.text(x1 + w1 / 2 + 1.0, (y2 + y1 + h1) / 2, f"FK {c} -> {rt}", fontsize=7.6,
                color="#1d4ed8", va="center",
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.9))
    ax.text(2, 16.5, "PK = primary key.   FK = foreign key (blue arrow); foreign keys exist only INSIDE one service.\n"
                     + LOGICAL_REFS[:LOGICAL_REFS.index(" are plain")] + " are plain values that name something\n"
                     "another service owns. They are NOT foreign keys: no table belongs to two services.",
            fontsize=9, va="center")
    fig.savefig(out_path, dpi=120, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def build_schema_drawio(out_path):
    cells, tid = [], {}
    for i, (service, tables) in enumerate(TABLES.items()):
        gx = 30 + i * 380
        total_h = 60 + sum(30 + 22 * len(c) + 30 for _, c in tables)
        gid = f"grp_{service.lower()}"
        cells.append(_cell(gid, f"<b>{service} service</b>",
                           f"rounded=1;html=1;verticalAlign=top;fontSize=15;fillColor={COLORS[service]};"
                           f"strokeColor={EDGE[service]};strokeWidth=2;opacity=60;", gx, 60, 350, total_h))
        y = 110
        for tname, cols in tables:
            rows = "".join(
                f"<tr><td><b>{escape(t)}</b></td><td>{escape(n)}</td><td>{escape(ty)}</td></tr>"
                for t, n, ty in (_row(c) for c in cols))
            label = (f"<div style='background:#333;color:#fff;padding:3px;text-align:center'><b>{tname}</b></div>"
                     f"<table style='width:100%;font-family:monospace;font-size:12px'>{rows}</table>")
            h = 30 + 22 * len(cols)
            tid[tname] = f"tbl_{tname}"
            cells.append(_cell(tid[tname], label,
                               "html=1;whiteSpace=wrap;align=left;verticalAlign=top;fillColor=#ffffff;strokeColor=#222222;",
                               gx + 15, y, 320, h))
            y += h + 30
    for n, (t, c, rt, rc) in enumerate(FKS):
        cells.append(
            f'<mxCell id="fk{n}" value={quoteattr(f"{c} -> {rc}")} style="endArrow=ERmandOne;startArrow=ERmany;'
            f'html=1;strokeColor=#1d4ed8;strokeWidth=2;labelBackgroundColor=#ffffff;" edge="1" parent="1" '
            f'source="{tid[t]}" target="{tid[rt]}"><mxGeometry relative="1" as="geometry"/></mxCell>')
    cells.append(_cell("legend", "PK = primary key. FK = foreign key (inside one service only). " + LOGICAL_REFS,
                       "text;html=1;align=left;whiteSpace=wrap;fontSize=12;", 30, 1000, 1480, 40))
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(_wrapper("ER diagram", cells))


# ----------------------------------------------------------------------------
# PDF helpers
# ----------------------------------------------------------------------------
def _pdf_kit():
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted,
                                    SimpleDocTemplate, Spacer, Table, TableStyle)
    ss = getSampleStyleSheet()
    st = {
        "title": ParagraphStyle("t", parent=ss["Title"], fontSize=20, spaceAfter=4),
        "h1": ParagraphStyle("h1", parent=ss["Heading1"], fontSize=14.5, spaceBefore=12, spaceAfter=5,
                             textColor=colors.HexColor("#1e3a8a")),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontSize=11.5, spaceBefore=8, spaceAfter=3),
        "body": ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=13),
        "cell": ParagraphStyle("c", parent=ss["BodyText"], fontSize=8.3, leading=10.6),
        "cellb": ParagraphStyle("cb", parent=ss["BodyText"], fontSize=8.3, leading=10.6, fontName="Helvetica-Bold"),
        "code": ParagraphStyle("code", fontName="Courier", fontSize=7.6, leading=9.6,
                               backColor=colors.HexColor("#f3f4f6"), borderPadding=5, leftIndent=4),
    }
    return dict(colors=colors, A4=A4, cm=cm, st=st, Image=Image, KeepTogether=KeepTogether,
                PageBreak=PageBreak, Paragraph=Paragraph, Preformatted=Preformatted,
                SimpleDocTemplate=SimpleDocTemplate, Spacer=Spacer, Table=Table, TableStyle=TableStyle)


def _table(k, rows, widths_cm, header=True):
    P, st, cm, colors = k["Paragraph"], k["st"], k["cm"], k["colors"]
    data = []
    for r, row in enumerate(rows):
        style = st["cellb"] if (header and r == 0) else st["cell"]
        data.append([P(escape(str(c)).replace("\n", "<br/>"), style) for c in row])
    t = k["Table"](data, colWidths=[w * cm for w in widths_cm], repeatRows=1 if header else 0)
    cmds = [("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#9ca3af")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    if header:
        cmds.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbeafe")))
    t.setStyle(k["TableStyle"](cmds))
    return t


def _team_block(k, team):
    P, st = k["Paragraph"], k["st"]
    rows = [("Roll No", "Name", "Responsible for")]
    for m in team["members"]:
        rows.append((m["roll"], m["name"], ", ".join(m.get("services", [])) or "-"))
    return [P(f"<b>Team ID:</b> {escape(team['team_id'])}", st["body"]), k["Spacer"](1, 4),
            _table(k, rows, [3.4, 6.0, 8.0])]


# ----------------------------------------------------------------------------
# design.pdf  (Assignment 2: Tasks 1, 3, 4, 6)
# ----------------------------------------------------------------------------
def build_design_pdf(team, out_path, services_png=None):
    k = _pdf_kit()
    P, st, cm, S = k["Paragraph"], k["st"], k["cm"], k["Spacer"]
    doc = k["SimpleDocTemplate"](out_path, pagesize=k["A4"], leftMargin=1.8 * cm, rightMargin=1.8 * cm,
                                 topMargin=1.6 * cm, bottomMargin=1.6 * cm, title=f"{PROJECT} Design",
                                 author=team["team_id"])
    s = [P(f"{PROJECT} - Design", st["title"]),
         P("CS 543 Web Services - Assignment 2: Services, Contracts and Schema", st["body"]), S(1, 6)]
    s += _team_block(k, team)

    s += [P("1. Capabilities (the verbs)", st["h1"]),
          P("Every distinct job CampusClub does, taken from the Assignment 1 brief. Each belongs to exactly one service.",
            st["body"]), S(1, 4),
          _table(k, [("#", "Capability", "Service")] + [(i + 1, c, sv) for i, (c, sv) in enumerate(CAPABILITIES)],
                 [1.0, 12.4, 4.0])]

    s += [P("2. Services and who implements them", st["h1"]),
          _table(k, [("Service", "Responsible member(s)", "Data it owns")] +
                 [(sv, team["owners"][sv], "; ".join(OWNS[sv])) for sv in OWNS], [2.9, 4.4, 10.1]), S(1, 6)]
    if services_png and os.path.exists(services_png):
        from PIL import Image as PILImage
        w, h = PILImage.open(services_png).size
        width = 17.2 * cm
        s += [k["Image"](services_png, width=width, height=width * h / w),
              P("Service design diagram (editable source: services.drawio).", st["cell"])]
    s += [P("Cross-service calls: " + "; ".join(f"{a} -> {b}: {op}" for a, b, op in CALLS) + ".", st["body"]),
          P("Students and organizers sign in through the college login; CampusClub only receives an opaque student reference, "
            "so no service owns a user table.", st["body"])]

    s += [k["PageBreak"](), P("3. Contracts", st["h1"]),
          P("Each table lists only what another service may call. It names operations, inputs, outputs and errors, "
            "and says nothing about how the service stores data or does the work inside. "
            "Events and Registrations are the two main services.", st["body"])]
    for sv, rows in CONTRACTS.items():
        s += [P(f"{sv} service", st["h2"]),
              _table(k, [("Operation", "Input", "Output", "Errors")] + rows, [2.9, 4.7, 4.5, 5.3])]

    s += [k["PageBreak"](), P("4. registerForEvent - full specification", st["h1"]),
          P("<b>Purpose.</b> Reserve a seat for the calling student at an event and issue a ticket. Owned by the Registrations service.",
            st["body"]), S(1, 4),
          P("Inputs", st["h2"]),
          _table(k, [("Input", "Rules"),
                     ("event", "Required. Reference to an existing event (a whole number)."),
                     ("phone", "Optional, 10 to 13 digits with an optional leading +. Used only to send a confirmation message."),
                     ("note", "Optional text, up to 200 characters."),
                     ("idempotency key", "Optional text, 1 to 128 characters. The same key with the same content returns the original registration."),
                     ("caller identity", "Supplied by authentication, not part of the content.")], [4.0, 13.4]),
          P("Outputs (success)", st["h2"]),
          P("Registration reference; event reference; student; status (registered); ticket code; note; notification state "
            "(sent, pending, failed or skipped); created time; where the registration can be cancelled and checked in.", st["body"]),
          P("Error cases", st["h2"]),
          _table(k, [("Error", "When it happens", "Effect"),
                     ("not-authenticated", "No valid caller identity.", "Nothing happens."),
                     ("validation-failed", "Any field is wrong; every bad field is reported together.", "No registration."),
                     ("unknown-event", "The event does not exist.", "No registration."),
                     ("event-closed", "The event is cancelled or has already started.", "No registration."),
                     ("event-full", "All seats are taken.", "No registration."),
                     ("already-registered", "The student already holds a seat for this event.", "No second seat."),
                     ("idempotency-key-reuse", "Same key, different content.", "Nothing happens."),
                     ("request-in-progress", "Same key is still being processed.", "Retry shortly."),
                     ("events-unavailable", "Event details cannot be obtained after retries; retry later.", "No registration.")],
                 [3.8, 8.8, 4.8]),
          P("Guarantees", st["h2"]),
          P("A student holds at most one seat per event, and registrations never exceed capacity (the check and the save "
            "cannot interleave for the same event). At most one registration per idempotency key. A failed confirmation "
            "message never undoes a registration: it only shows in the notification state. Callers only ever see the vocabulary of this contract.",
            st["body"]),
          P("Internal details registerForEvent must hide from callers", st["h2"]),
          _table(k, [("Hidden detail", "Why it stays inside"),
                     ("How event details (capacity, open state) are obtained, and the timeouts, retries and back-off used", "Callers must not depend on how Events is reached; they only see success or a clean error."),
                     ("How seats are counted and how simultaneous requests for the last seat are ordered", "The counting method can change without breaking callers."),
                     ("How the ticket code is made", "Callers only need it to be unique and short."),
                     ("Which SMS provider and protocol sends the confirmation, and its fault words", "The provider can change without breaking callers."),
                     ("That the confirmation is best effort and may be retried later", "Callers see only the notification state."),
                     ("How and where registrations and idempotency records are stored", "Storage can change freely.")], [8.6, 8.8])]

    s += [k["PageBreak"](), P("6. Validation: the five properties of a Service", st["h1"]),
          _table(k, [("Service", "Reachable", "Self-contained", "Has a contract", "Independent", "Loosely coupled"),
                     ("Clubs", "Pass", "Pass", "Pass", "Pass", "Pass"),
                     ("Events", "Pass", "Pass", "Pass", "PARTIAL", "Pass"),
                     ("Registrations", "Pass", "Pass", "Pass", "PARTIAL", "Pass"),
                     ("Notifications", "Pass", "Pass", "Pass", "Pass", "Pass")], [2.9, 2.5, 3.0, 3.0, 3.0, 3.0]),
          S(1, 8), P("Where a property fails, and the fix", st["h2"]),
          _table(k, [("Service", "Property", "Problem", "How to fix it"),
                     ("Events", "Independent",
                      "createEvent cannot succeed while Clubs is down, because it verifies the club first. Reads (listEvents, getEvent) and updates work alone.",
                      "Fail fast with a clean 503 and Retry-After, as now; or accept the event as pending and verify the club later, once Clubs is back."),
                     ("Registrations", "Independent",
                      "registerForEvent cannot succeed while Events is down, because capacity and open state are unknown. Reads, cancellation and check-in work alone.",
                      "Keep failing cleanly (a seat must never be sold without knowing the capacity); optionally keep a short-lived copy of event details to serve the common case. The confirmation message is already best effort, so Notifications being down never blocks a registration.")],
                 [2.3, 2.5, 6.2, 6.4]),
          S(1, 8),
          P("Reasons for the passes. <b>Reachable</b>: every service is called over the network through named operations. "
            "<b>Self-contained</b>: each owns all the data it needs. <b>Has a contract</b>: section 3. "
            "<b>Independent</b>: Clubs and Notifications call no other CampusClub service (Notifications only wraps an outside SMS gateway). "
            "<b>Loosely coupled</b>: services exchange references and simple values, never tables or shared code, and no service calls back into the one that called it.",
            st["body"])]
    doc.build(s)


# ----------------------------------------------------------------------------
# integration.pdf  (Assignment 3: Tasks 1, 4, 5, 6)
# ----------------------------------------------------------------------------
ENDPOINT = "https://api.campussms.example.com/soap/v1/sms"
SOAP_ACTION = "http://sms.campussms.example.com/gateway/v1/sendSMS"


def build_integration_pdf(team, out_path, request_xml_path):
    k = _pdf_kit()
    P, st, cm, S, Pre = k["Paragraph"], k["st"], k["cm"], k["Spacer"], k["Preformatted"]
    size = os.path.getsize(request_xml_path) if os.path.exists(request_xml_path) else 0
    doc = k["SimpleDocTemplate"](out_path, pagesize=k["A4"], leftMargin=1.8 * cm, rightMargin=1.8 * cm,
                                 topMargin=1.6 * cm, bottomMargin=1.6 * cm, title=f"{PROJECT} SOAP Integration",
                                 author=team["team_id"])
    s = [P(f"{PROJECT} - SOAP Partner Integration", st["title"]),
         P("CS 543 Web Services - Assignment 3", st["body"]), S(1, 6)]
    rows = [("Roll No", "Name")] + [(m["roll"], m["name"]) for m in team["members"]]
    s += [P(f"<b>Team ID:</b> {escape(team['team_id'])}", st["body"]), S(1, 4), _table(k, rows, [4.0, 9.0])]

    s += [P("1. Context", st["h1"]),
          P("<b>Partner:</b> CampusSMS Gateway, an external SMS provider. <b>Operation integrated:</b> "
            "<b>sendSMS</b> (send a confirmation or reminder text to a student's phone).", st["body"]), S(1, 3),
          P("CampusClub's own services speak REST and JSON because the React app needs simple, cacheable and fast calls. "
            "The SMS edge is different: it is run by a telecom company, every message costs money and carries a student's phone number, "
            "so both sides need a strict contract (WSDL plus XML Schema) that rejects a malformed message before anything is sent. "
            "SOAP also provides message-level security, because WS-Security signs the credentials in the message header so they stay protected through every proxy and queue instead of only on one TLS hop. "
            "Finally SOAP has a standard fault format that tells a bad number apart from an unavailable gateway, and a unique message reference makes a repeated send detectable.",
            st["body"])]

    s += [P("2. HTTP binding", st["h1"]),
          P("The request in soap-request.xml travels as one HTTP POST to the endpoint from the WSDL service/port element:", st["body"]),
          S(1, 3),
          Pre(f"POST /soap/v1/sms HTTP/1.1\n"
              f"Host: api.campussms.example.com\n"
              f"Content-Type: text/xml; charset=utf-8\n"
              f"Content-Length: {size}\n"
              f'SOAPAction: "{SOAP_ACTION}"\n\n'
              f"<soap:Envelope> ... contents of soap-request.xml ... </soap:Envelope>", st["code"]),
          S(1, 4),
          _table(k, [("Part", "Value", "Where it comes from"),
                     ("Method", "POST", "SOAP over HTTP always uses POST"),
                     ("Endpoint URL", ENDPOINT, "soap:address location in the WSDL service/port"),
                     ("Host", "api.campussms.example.com", "host part of the endpoint"),
                     ("Content-Type", "text/xml; charset=utf-8", "SOAP 1.1"),
                     ("SOAPAction", f'"{SOAP_ACTION}"', "soap:operation soapAction in the WSDL binding")], [3.0, 7.4, 7.0])]

    s += [P("3. Discovery", st["h1"]),
          P("CampusClub does not run a UDDI server. It obtains the contract at design time by a direct URL: the gateway publishes "
            f"its WSDL at {ENDPOINT}?wsdl, and the team saves a copy as partner.wsdl in the repository (version controlled, so a change by the partner "
            "is noticed in code review). The endpoint used at run time is read from configuration (SMS_GATEWAY_URL), never hard-coded. "
            "The same information is recorded in the team's service catalogue as one registry entry in the UDDI style:", st["body"]),
          S(1, 4),
          _table(k, [("Field", "Value"),
                     ("Business", "CampusSMS Communications Pvt Ltd (businessKey: campussms-comm)"),
                     ("Service", "SmsGatewayService (serviceKey: campussms-gateway-v1)"),
                     ("Endpoint (accessPoint)", ENDPOINT),
                     ("WSDL it speaks (tModel-style pointer)", f"tModel: SmsGateway WSDL v1 -> {ENDPOINT}?wsdl (copy in repo: partner.wsdl)"),
                     ("Binding", "SOAP 1.1, document/literal, over HTTP"),
                     ("Operations", "sendSMS"),
                     ("Used by", "CampusClub Notifications service")], [5.4, 12.0])]

    s += [P("4. Fault mapping", st["h1"]),
          P("The partner's fault vocabulary must never reach a student. One adapter in the Notifications service (smsGateway.js) converts every partner fault into the error "
            "that the Assignment 2 contract promised for sendNotification:", st["body"]), S(1, 3),
          _table(k, [("Partner fault", "CampusClub contract error", "HTTP", "Message in our words"),
                     ("soap:Client / SmsFault INVALID_NUMBER", "recipient-unreachable", "422", "The phone number could not receive the message."),
                     ("soap:Server / GATEWAY_UNAVAILABLE, soap:Server / INSUFFICIENT_CREDITS, timeout, no connection", "notifications-unavailable", "503", "Notifications are temporarily unavailable; the message was not sent. (Retry-After set)"),
                     ("soap:Client / AUTH_FAILED (our credentials wrong)", "upstream-error", "502", "A dependent service returned an unexpected answer. (Our team is alerted.)"),
                     ("Anything else", "upstream-error", "502", "same as above")], [5.2, 3.5, 1.2, 7.5]),
          S(1, 5),
          Pre('function mapFault(parsed) {\n'
              '  switch (parsed.code) {\n'
              "    case 'INVALID_NUMBER':       return new ApiError('recipient-unreachable', ...);\n"
              "    case 'INSUFFICIENT_CREDITS':\n"
              "    case 'GATEWAY_UNAVAILABLE':  return new ApiError('notifications-unavailable', ...);\n"
              "    default:                     return new ApiError('upstream-error', ...);  // incl. AUTH_FAILED\n"
              '  }\n'
              '}', st["code"]),
          S(1, 5),
          P("Example: the partner answers with soap-fault.xml (invalid number). Notifications returns:", st["body"]),
          Pre('HTTP/1.1 422 Unprocessable Entity\nContent-Type: application/problem+json\n\n'
              '{"type": "https://campusclub.example/problems/recipient-unreachable",\n'
              ' "title": "Recipient cannot be reached", "status": 422,\n'
              ' "detail": "The phone number could not receive the message."}', st["code"]),
          S(1, 4),
          P("In registerForEvent this becomes the notification state, not a failed registration: recipient-unreachable shows as "
            "\"failed\" and notifications-unavailable as \"pending\", and the student is registered either way. "
            "The words INVALID_NUMBER, SmsFault and soap:Client appear nowhere in any response.", st["body"])]
    doc.build(s)


# ----------------------------------------------------------------------------
# NOTES team block
# ----------------------------------------------------------------------------
def team_markdown(team):
    rows = "\n".join(f"| {m['roll']} | {m['name']} |" for m in team["members"])
    return f"**Team ID:** {team['team_id']}\n\n| Roll No | Name |\n|---|---|\n{rows}"


def fill_markdown(path, team):
    """Replace everything between <!--TEAM--> and <!--/TEAM--> in a markdown file."""
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    new = re.sub(r"<!--TEAM-->.*?<!--/TEAM-->", lambda m: "<!--TEAM-->\n" + team_markdown(team) + "\n<!--/TEAM-->",
                 text, flags=re.S)
    if new != text:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(new)
        return True
    return False
