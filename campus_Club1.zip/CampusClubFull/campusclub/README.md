# CampusClub

**One platform for managing college clubs, events and student participation.**
Managing clubs, events, registrations and attendance by hand is slow and error-prone; CampusClub lets students
find clubs, join them, register for events and get a ticket, and lets organizers create events and check students in at the door.

<!--TEAM-->
**Team ID:** TEAM-00

| Roll No | Name |
|---|---|
| ROLL-1 | Member One |
| ROLL-2 | Member Two |
| ROLL-3 | Member Three |
| ROLL-4 | Member Four |
<!--/TEAM-->

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | ReactJS (Vite) + TailwindCSS |
| Backend | Node.js + Express.js, REST APIs (four small services) |
| Database | MySQL 8 (each service owns its own tables) |

## Architecture

```
React (5173) --/api/*--> Clubs (4001) <-- checkClub -- Events (4002) <-- getEvent -- Registrations (4003) -- sendNotification --> Notifications (4004) --SOAP--> SMS gateway
                                  MySQL database "campusclub": every table belongs to exactly one service
```

## Run it (Windows, VS Code terminal)

1. Install **Node.js 20+**, **MySQL 8** (keep it running) and **Python 3.10+** (only for the document tools).
2. Backend:
   ```
   cd backend
   copy .env.example .env        (edit DB_PASSWORD in .env)
   npm install
   npm run db:init               (creates the database, tables and demo data)
   npm start                     (starts all four services)
   ```
3. Frontend (second terminal):
   ```
   cd frontend
   npm install
   npm run dev                   (open http://localhost:5173)
   ```
4. Sign in as a student (e.g. `21CS001`) or as an organizer to create clubs and events.

No MySQL yet? Set `STORE=memory` in `backend/.env` to try everything without a database (nothing is saved).

## Where each assignment lives

| Assignment | Files |
|---|---|
| 1 HTTP by hand + setup | `README.md`, `brief.md`, `http-log.md`, `network-analysis.md`, `docs/` |
| 2 Design | `assignment2/` (`design.pdf`, `services.drawio/png`, `schema.drawio/png/sql`) |
| 3 SOAP partner | `assignment3/` (`integration.pdf`, `partner.wsdl`, `soap-*.xml`); code: `backend/services/notifications/smsGateway.js` |
| 4 REST service | `assignment4/NOTES.md` + evidence; code: `backend/services/registrations/` |
| 5 Methods and headers | `assignment5/NOTES.md` + evidence; code: `backend/lib/http.js`, `registrations/app.js` |
| 6 Honest responses | `assignment6/NOTES.md` + evidence; code: `backend/lib/problem.js`, `registrations/models.js` |

Step-by-step instructions for everything: **GUIDE_HINGLISH.md**.
