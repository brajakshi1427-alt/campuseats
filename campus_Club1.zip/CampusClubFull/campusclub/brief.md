# CampusClub Brief

## What the system does
CampusClub is a single platform for managing college clubs, their events and student participation. A student browses
the clubs on campus, joins the ones they like, sees upcoming events, registers for an event and receives a ticket and a
confirmation message. Club organizers create clubs and events, set how many seats there are, and check students in at the door,
so attendance is recorded without paper lists. It replaces notice-board posters, forms and spreadsheets, which are slow, easy to
get wrong and impossible to keep up to date.

## Who uses it
- **Students** - find and join clubs, browse events, register, cancel, show their ticket.
- **Club organizers (office-bearers)** - create the club's events, change or cancel them, see who registered, check people in.
- **Administrator** - adds clubs and oversees the whole system.
- **SMS gateway** (an outside partner, not a person) - delivers confirmation and reminder texts.

## Nouns (the things and the services that own them)
| Noun | Meaning | Service |
|---|---|---|
| Club | A student club with a name, category and description | Clubs |
| Membership | A student's membership of a club, with a role | Clubs |
| Event | A talk, workshop, contest or meeting run by a club | Events |
| Capacity | How many seats an event has | Events |
| Registration | One student's seat at one event, with a ticket code | Registrations |
| Attendance | The record that a student actually came (check-in) | Registrations |
| Notification | A message sent to a student, with its delivery status | Notifications |

Services: **Clubs, Events, Registrations, Notifications**.

## Verbs (the actions / tasks / contracts)
| Verb | Done by | Acts on |
|---|---|---|
| Create a club | Organizer | Club |
| Browse and search clubs | Student | Club |
| Join / leave a club | Student | Membership |
| List members | Organizer | Membership |
| Create / update an event | Organizer | Event |
| Browse upcoming events | Student | Event |
| Cancel an event | Organizer | Event |
| Register for an event | Student | Registration |
| Cancel a registration | Student | Registration |
| Check a student in | Organizer | Attendance |
| Track registrations and attendance | Organizer | Registration, Attendance |
| Send a confirmation message | Registrations (asks Notifications) | Notification |

Every verb acts on one of the nouns above, and together the nouns and verbs are the starting point for the services and contracts designed in Assignment 2.
