import React, { useCallback, useEffect, useState } from 'react';
import { request } from '../api.js';
import { Badge, Button, Card, Field, Notice, ProblemAlert, fmtDate, statusTone, inputClass } from '../ui.jsx';

export default function OrganizerPage({ user }) {
  const [clubs, setClubs] = useState([]);
  const [events, setEvents] = useState([]);
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');
  const [club, setClub] = useState({ name: '', category: 'technical', description: '' });
  const [ev, setEv] = useState({ club_id: '', title: '', venue: '', starts_at: '', capacity: 30 });
  const [selected, setSelected] = useState('');
  const [regs, setRegs] = useState([]);

  const load = useCallback(async () => {
    try {
      const [c, e] = await Promise.all([request('clubs', 'GET', '?limit=50', { user }), request('events', 'GET', '?limit=50', { user })]);
      setClubs(c.data.items); setEvents(e.data.items);
    } catch (err) { setProblem(err); }
  }, [user]);
  useEffect(() => { load(); }, [load]);

  const loadRegs = useCallback(async () => {
    if (!selected) { setRegs([]); return; }
    try {
      const r = await request('registrations', 'GET', `?event_id=${selected}&limit=50&sort=created_at`, { user });
      setRegs(r.data.items);
    } catch (err) { setProblem(err); }
  }, [user, selected]);
  useEffect(() => { loadRegs(); }, [loadRegs]);

  const run = async (fn, okText) => {
    try { await fn(); setNotice(okText); setProblem(null); load(); loadRegs(); } catch (e) { setNotice(''); setProblem(e); }
  };

  const createClub = () => run(
    () => request('clubs', 'POST', '', { user, body: { name: club.name, category: club.category, ...(club.description ? { description: club.description } : {}) } }),
    `Club "${club.name}" created.`);
  const createEvent = () => run(
    () => request('events', 'POST', '', { user, body: {
      club_id: Number(ev.club_id), title: ev.title, venue: ev.venue,
      starts_at: ev.starts_at ? new Date(ev.starts_at).toISOString() : '', capacity: Number(ev.capacity) } }),
    `Event "${ev.title}" created.`);
  const checkIn = (r) => run(() => request('registrations', 'POST', `/${r.id}/attendance`, { user }), `${r.student} checked in.`);
  const cancelEvent = (e) => run(() => request('events', 'POST', `/${e.id}/cancellation`, { user }), `Event "${e.title}" cancelled.`);

  return (
    <div className="space-y-6">
      <ProblemAlert problem={problem} onClose={() => setProblem(null)} />
      {notice && <Notice onClose={() => setNotice('')}>{notice}</Notice>}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-semibold">Create a club</h3>
          <div className="space-y-3">
            <Field label="Name"><input className={inputClass} value={club.name} onChange={(e) => setClub({ ...club, name: e.target.value })} /></Field>
            <Field label="Category">
              <select className={inputClass} value={club.category} onChange={(e) => setClub({ ...club, category: e.target.value })}>
                {['technical', 'cultural', 'sports', 'literary', 'social', 'other'].map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Description"><input className={inputClass} value={club.description} onChange={(e) => setClub({ ...club, description: e.target.value })} /></Field>
            <Button onClick={createClub}>Create club</Button>
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 font-semibold">Create an event</h3>
          <div className="space-y-3">
            <Field label="Club">
              <select className={inputClass} value={ev.club_id} onChange={(e) => setEv({ ...ev, club_id: e.target.value })}>
                <option value="">Choose a club</option>
                {clubs.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Title"><input className={inputClass} value={ev.title} onChange={(e) => setEv({ ...ev, title: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Venue"><input className={inputClass} value={ev.venue} onChange={(e) => setEv({ ...ev, venue: e.target.value })} /></Field>
              <Field label="Capacity"><input type="number" className={inputClass} value={ev.capacity} onChange={(e) => setEv({ ...ev, capacity: e.target.value })} /></Field>
            </div>
            <Field label="Starts at"><input type="datetime-local" className={inputClass} value={ev.starts_at} onChange={(e) => setEv({ ...ev, starts_at: e.target.value })} /></Field>
            <Button onClick={createEvent}>Create event</Button>
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="mb-3 font-semibold">Attendance</h3>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <select className={`${inputClass} max-w-sm`} value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">Choose an event</option>
            {events.map((e) => <option key={e.id} value={e.id}>{e.title} ({e.status})</option>)}
          </select>
          {selected && events.find((e) => String(e.id) === selected && e.status === 'open') && (
            <Button variant="danger" onClick={() => cancelEvent(events.find((e) => String(e.id) === selected))}>Cancel this event</Button>
          )}
        </div>
        {selected && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead><tr className="border-b text-slate-500"><th className="py-2">Student</th><th>Ticket</th><th>Status</th><th>Checked in</th><th></th></tr></thead>
              <tbody>
                {regs.map((r) => (
                  <tr key={r.id} className="border-b last:border-0">
                    <td className="py-2">{r.student}</td>
                    <td className="font-mono">{r.ticket_code}</td>
                    <td><Badge tone={statusTone(r.status)}>{r.status}</Badge></td>
                    <td>{fmtDate(r.checked_in_at)}</td>
                    <td className="text-right">{r.status === 'registered' && <Button onClick={() => checkIn(r)}>Check in</Button>}</td>
                  </tr>
                ))}
                {regs.length === 0 && <tr><td colSpan="5" className="py-3 text-slate-500">No registrations for this event yet.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
