import React, { useCallback, useEffect, useState } from 'react';
import { request } from '../api.js';
import { Badge, Button, Card, Notice, ProblemAlert, fmtDate, statusTone, inputClass } from '../ui.jsx';

export default function MyRegistrationsPage({ user }) {
  const [rows, setRows] = useState([]);
  const [events, setEvents] = useState({});
  const [status, setStatus] = useState('');
  const [editing, setEditing] = useState(null);
  const [text, setText] = useState('');
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    try {
      const q = new URLSearchParams({ limit: '50', sort: '-created_at' });
      if (status) q.set('status', status);
      const [r, e] = await Promise.all([
        request('registrations', 'GET', `?${q}`, { user }),
        request('events', 'GET', '?limit=50', { user }),
      ]);
      setRows(r.data.items);
      setEvents(Object.fromEntries(e.data.items.map((x) => [x.id, x])));
      setProblem(null);
    } catch (err) { setProblem(err); }
  }, [user, status]);
  useEffect(() => { load(); }, [load]);

  const cancel = async (r) => {
    try {
      await request('registrations', 'POST', `/${r.id}/cancellation`, { user });
      setNotice('Registration cancelled. Your seat is free for someone else.'); setProblem(null); load();
    } catch (e) { setNotice(''); setProblem(e); }
  };

  // Edit the note safely: read the registration to get its ETag, then PATCH with If-Match.
  const saveNote = async (r) => {
    try {
      const current = await request('registrations', 'GET', `/${r.id}`, { user });
      await request('registrations', 'PATCH', `/${r.id}`, { user, body: { note: text }, headers: { 'If-Match': current.etag } });
      setEditing(null); setNotice('Note saved.'); setProblem(null); load();
    } catch (e) { setNotice(''); setProblem(e); }
  };

  return (
    <div>
      <div className="mb-4">
        <select className={`${inputClass} max-w-[12rem]`} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="registered">Registered</option>
          <option value="attended">Attended</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>
      <ProblemAlert problem={problem} onClose={() => setProblem(null)} />
      {notice && <Notice onClose={() => setNotice('')}>{notice}</Notice>}
      <div className="grid gap-4">
        {rows.map((r) => {
          const ev = events[r.event_id];
          return (
            <Card key={r.id}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h3 className="text-lg font-semibold">{ev ? ev.title : `Event #${r.event_id}`}</h3>
                  <p className="text-sm text-slate-500">{ev ? `${ev.venue} - ${fmtDate(ev.starts_at)}` : ''}</p>
                </div>
                <div className="text-right">
                  <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                  <p className="mt-1 font-mono text-sm">Ticket {r.ticket_code}</p>
                </div>
              </div>
              <p className="mt-2 text-sm text-slate-600">Note: {r.note || '-'} - SMS: {r.notification}{r.checked_in_at ? ` - checked in ${fmtDate(r.checked_in_at)}` : ''}</p>
              {r.status === 'registered' && (
                editing === r.id ? (
                  <div className="mt-3 flex gap-2">
                    <input className={inputClass} value={text} onChange={(e) => setText(e.target.value)} />
                    <Button onClick={() => saveNote(r)}>Save</Button>
                    <Button variant="ghost" onClick={() => setEditing(null)}>Close</Button>
                  </div>
                ) : (
                  <div className="mt-3 flex gap-2">
                    <Button variant="ghost" onClick={() => { setEditing(r.id); setText(r.note || ''); }}>Edit note</Button>
                    <Button variant="danger" onClick={() => cancel(r)}>Cancel registration</Button>
                  </div>
                )
              )}
            </Card>
          );
        })}
        {rows.length === 0 && !problem && <p className="text-sm text-slate-500">You have no registrations yet.</p>}
      </div>
    </div>
  );
}
