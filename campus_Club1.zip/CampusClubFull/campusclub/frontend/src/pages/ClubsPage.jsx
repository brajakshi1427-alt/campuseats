import React, { useCallback, useEffect, useState } from 'react';
import { request } from '../api.js';
import { Badge, Button, Card, Notice, ProblemAlert, inputClass } from '../ui.jsx';

const CATEGORIES = ['technical', 'cultural', 'sports', 'literary', 'social', 'other'];

export default function ClubsPage({ user }) {
  const [clubs, setClubs] = useState([]);
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({ limit: '50' });
      if (q) params.set('q', q);
      if (category) params.set('category', category);
      const r = await request('clubs', 'GET', `?${params}`, { user });
      setClubs(r.data.items);
      setProblem(null);
    } catch (e) { setProblem(e); }
  }, [user, q, category]);

  useEffect(() => { load(); }, [load]);

  const join = async (club) => {
    try {
      await request('clubs', 'POST', `/${club.id}/memberships`, { user });
      setNotice(`You joined ${club.name}.`); setProblem(null); load();
    } catch (e) { setNotice(''); setProblem(e); }
  };
  const leave = async (club) => {
    try {
      await request('clubs', 'DELETE', `/${club.id}/memberships/me`, { user });
      setNotice(`You left ${club.name}.`); setProblem(null); load();
    } catch (e) { setNotice(''); setProblem(e); }
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2">
        <input className={`${inputClass} max-w-xs`} placeholder="Search clubs" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className={`${inputClass} max-w-[10rem]`} value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <ProblemAlert problem={problem} onClose={() => setProblem(null)} />
      {notice && <Notice onClose={() => setNotice('')}>{notice}</Notice>}
      <div className="grid gap-4 sm:grid-cols-2">
        {clubs.map((c) => (
          <Card key={c.id}>
            <div className="flex items-start justify-between">
              <h3 className="text-lg font-semibold">{c.name}</h3>
              <Badge tone="blue">{c.category}</Badge>
            </div>
            <p className="mt-1 text-sm text-slate-600">{c.description}</p>
            <p className="mt-2 text-xs text-slate-500">{c.member_count} member(s) - president {c.president}</p>
            <div className="mt-3 flex gap-2">
              <Button onClick={() => join(c)}>Join</Button>
              <Button variant="ghost" onClick={() => leave(c)}>Leave</Button>
            </div>
          </Card>
        ))}
        {clubs.length === 0 && !problem && <p className="text-sm text-slate-500">No clubs found.</p>}
      </div>
    </div>
  );
}
