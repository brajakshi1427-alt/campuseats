import React, { useCallback, useEffect, useRef, useState } from 'react';
import { request, newKey } from '../api.js';
import { Badge, Button, Card, Field, Notice, ProblemAlert, fmtDate, inputClass } from '../ui.jsx';

export default function EventsPage({ user }) {
  const [events, setEvents] = useState([]);
  const [clubs, setClubs] = useState({});
  const [openId, setOpenId] = useState(null);
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');
  const [problem, setProblem] = useState(null);
  const [notice, setNotice] = useState('');
  const key = useRef(null);          // one Idempotency-Key per registration attempt (a retry reuses it)

  const load = useCallback(async () => {
    try {
      const [e, c] = await Promise.all([
        request('events', 'GET', '?status=open&upcoming=true&limit=50', { user }),
        request('clubs', 'GET', '?limit=50', { user }),
      ]);
      setEvents(e.data.items);
      setClubs(Object.fromEntries(c.data.items.map((x) => [x.id, x.name])));
      setProblem(null);
    } catch (err) { setProblem(err); }
  }, [user]);
  useEffect(() => { load(); }, [load]);

  const register = async (ev) => {
    if (!key.current) key.current = newKey();
    const body = { event_id: ev.id };
    if (phone) body.phone = phone;
    if (note) body.note = note;
    try {
      const r = await request('registrations', 'POST', '', { user, body, headers: { 'Idempotency-Key': key.current } });
      const sms = { sent: 'A confirmation SMS was sent.', pending: 'Your SMS confirmation is delayed, but you are registered.', failed: 'We could not SMS that number, but you are registered.', skipped: '' }[r.data.notification];
      setNotice(`Registered for "${ev.title}". Your ticket code is ${r.data.ticket_code}. ${sms}`);
      setProblem(null); setOpenId(null); setPhone(''); setNote(''); key.current = null;
    } catch (err) {
      setNotice(''); setProblem(err);
      if (err.status && err.status < 500 && err.status !== 429) key.current = null;   // a refused request gets a fresh key next time
    }
  };

  return (
    <div>
      <ProblemAlert problem={problem} onClose={() => setProblem(null)} />
      {notice && <Notice onClose={() => setNotice('')}>{notice}</Notice>}
      <div className="grid gap-4">
        {events.map((ev) => (
          <Card key={ev.id}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h3 className="text-lg font-semibold">{ev.title}</h3>
                <p className="text-sm text-slate-500">{clubs[ev.club_id] || `Club #${ev.club_id}`} - {ev.venue}</p>
              </div>
              <div className="text-right text-sm">
                <p className="font-medium">{fmtDate(ev.starts_at)}</p>
                <Badge tone="slate">capacity {ev.capacity}</Badge>
              </div>
            </div>
            {ev.description && <p className="mt-2 text-sm text-slate-600">{ev.description}</p>}
            {openId === ev.id ? (
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <Field label="Phone for SMS (optional)">
                  <input className={inputClass} placeholder="9876543210" value={phone} onChange={(e) => setPhone(e.target.value)} />
                </Field>
                <Field label="Note (optional)">
                  <input className={inputClass} value={note} onChange={(e) => setNote(e.target.value)} />
                </Field>
                <div className="flex items-end gap-2">
                  <Button onClick={() => register(ev)}>Confirm</Button>
                  <Button variant="ghost" onClick={() => { setOpenId(null); key.current = null; }}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div className="mt-3"><Button onClick={() => { setOpenId(ev.id); key.current = null; setProblem(null); }}>Register</Button></div>
            )}
          </Card>
        ))}
        {events.length === 0 && !problem && <p className="text-sm text-slate-500">No upcoming events yet.</p>}
      </div>
    </div>
  );
}
