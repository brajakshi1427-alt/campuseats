import React, { useState } from 'react';
import ClubsPage from './pages/ClubsPage.jsx';
import EventsPage from './pages/EventsPage.jsx';
import MyRegistrationsPage from './pages/MyRegistrationsPage.jsx';
import OrganizerPage from './pages/OrganizerPage.jsx';
import { Button, Card, Field, inputClass } from './ui.jsx';

const load = () => { try { return JSON.parse(localStorage.getItem('campusclub-user')); } catch (e) { return null; } };

function Login({ onLogin }) {
  const [role, setRole] = useState('student');
  const [ref, setRef] = useState('21CS001');
  return (
    <div className="mx-auto mt-24 max-w-sm">
      <Card>
        <h1 className="mb-1 text-2xl font-bold text-indigo-700">CampusClub</h1>
        <p className="mb-4 text-sm text-slate-500">Clubs, events and attendance in one place.</p>
        <div className="space-y-3">
          <Field label="I am a">
            <select className={inputClass} value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="student">Student</option>
              <option value="organizer">Club organizer</option>
              <option value="admin">Admin</option>
            </select>
          </Field>
          <Field label="Roll number / ID">
            <input className={inputClass} value={ref} onChange={(e) => setRef(e.target.value.trim())} />
          </Field>
          <Button className="w-full" disabled={!ref} onClick={() => onLogin({ role, ref })}>Continue</Button>
          <p className="text-xs text-slate-400">Demo sign-in: the role and ID are sent as a Bearer token (header handling only, no password).</p>
        </div>
      </Card>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(load);
  const [tab, setTab] = useState('events');
  if (!user) {
    return <Login onLogin={(u) => { localStorage.setItem('campusclub-user', JSON.stringify(u)); setUser(u); }} />;
  }
  const staff = user.role === 'organizer' || user.role === 'admin';
  const tabs = [['events', 'Events'], ['clubs', 'Clubs'], ['mine', 'My registrations'], ...(staff ? [['organizer', 'Organizer']] : [])];
  return (
    <div>
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <span className="text-xl font-bold text-indigo-700">CampusClub</span>
          <nav className="flex gap-1">
            {tabs.map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium ${tab === id ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>{label}</button>
            ))}
          </nav>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <span>{user.role}: <b>{user.ref}</b></span>
            <Button variant="ghost" onClick={() => { localStorage.removeItem('campusclub-user'); setUser(null); }}>Sign out</Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">
        {tab === 'events' && <EventsPage user={user} />}
        {tab === 'clubs' && <ClubsPage user={user} />}
        {tab === 'mine' && <MyRegistrationsPage user={user} />}
        {tab === 'organizer' && staff && <OrganizerPage user={user} />}
      </main>
    </div>
  );
}
