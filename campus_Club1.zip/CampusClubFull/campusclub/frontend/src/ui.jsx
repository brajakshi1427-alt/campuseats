import React from 'react';

export const Card = ({ children, className = '' }) => (
  <div className={`rounded-xl border border-slate-200 bg-white p-5 shadow-sm ${className}`}>{children}</div>
);

const styles = {
  primary: 'bg-indigo-600 text-white hover:bg-indigo-700 disabled:bg-indigo-300',
  ghost: 'border border-slate-300 text-slate-700 hover:bg-slate-100 disabled:opacity-50',
  danger: 'bg-rose-600 text-white hover:bg-rose-700 disabled:bg-rose-300',
};
export const Button = ({ variant = 'primary', className = '', ...props }) => (
  <button className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${styles[variant]} ${className}`} {...props} />
);

const tones = {
  green: 'bg-emerald-100 text-emerald-800', amber: 'bg-amber-100 text-amber-800',
  red: 'bg-rose-100 text-rose-800', slate: 'bg-slate-100 text-slate-700', blue: 'bg-sky-100 text-sky-800',
};
export const Badge = ({ tone = 'slate', children }) => (
  <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>
);

export const statusTone = (s) => ({ registered: 'blue', attended: 'green', cancelled: 'red', open: 'green' }[s] || 'slate');

// Shows a Problem Details failure, including the field-level errors list.
export function ProblemAlert({ problem, onClose }) {
  if (!problem) return null;
  return (
    <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800">
      <div className="flex justify-between gap-3">
        <div>
          <p className="font-semibold">{problem.title}{problem.status ? ` (${problem.status})` : ''}</p>
          <p>{problem.message}</p>
          {problem.errors && problem.errors.length > 0 && (
            <ul className="mt-1 list-disc pl-5">
              {problem.errors.map((e, i) => <li key={i}><b>{e.field}</b>: {e.message}</li>)}
            </ul>
          )}
        </div>
        {onClose && <button onClick={onClose} className="text-rose-600">x</button>}
      </div>
    </div>
  );
}

export const Notice = ({ children, onClose }) => (
  <div className="mb-4 flex justify-between rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
    <span>{children}</span>
    {onClose && <button onClick={onClose} className="text-emerald-700">x</button>}
  </div>
);

export const Field = ({ label, children }) => (
  <label className="block text-sm">
    <span className="mb-1 block font-medium text-slate-700">{label}</span>
    {children}
  </label>
);
export const inputClass = 'w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm focus:border-indigo-500 focus:outline-none';

export const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '');
