// Tiny API client. Every failure from the services is a Problem Details object
// (type, title, status, detail, errors[]); we turn it into an ApiProblem you can show to the user.

const BASE = {
  clubs: '/api/clubs',
  events: '/api/events',
  registrations: '/api/registrations',
  notifications: '/api/notifications',
};

export class ApiProblem extends Error {
  constructor(problem, status) {
    super(problem.detail || problem.title || 'Request failed');
    this.status = status;
    this.title = problem.title;
    this.kind = problem.type ? String(problem.type).split('/').pop() : 'error';
    this.errors = problem.errors || [];
  }
}

export async function request(service, method, path, { user, body, headers = {} } = {}) {
  const h = { Accept: 'application/json', ...headers };
  if (user) h.Authorization = `Bearer ${user.role}:${user.ref}`;
  if (body !== undefined) h['Content-Type'] = 'application/json';
  let res;
  try {
    res = await fetch(BASE[service] + path, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (e) {
    throw new ApiProblem({ title: 'Network error', detail: 'Cannot reach the CampusClub services. Are they running (npm start)?' }, 0);
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
  if (!res.ok) throw new ApiProblem(data || { title: res.statusText }, res.status);
  return { data, etag: res.headers.get('ETag'), status: res.status };
}

export const newKey = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
