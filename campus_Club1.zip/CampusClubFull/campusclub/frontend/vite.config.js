import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The React app calls /api/<service>/...; the dev server forwards each one to its service
// (and removes the /api prefix), so the browser only ever talks to http://localhost:5173.
const to = (port) => ({ target: `http://127.0.0.1:${port}`, changeOrigin: true, rewrite: (p) => p.replace(/^\/api/, '') });

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api/clubs': to(4001),
      '/api/events': to(4002),
      '/api/registrations': to(4003),
      '/api/notifications': to(4004),
    },
  },
});
