# CS 543 - Assignment 6 - NOTES (CampusClub)

<!--TEAM-->
**Team ID:** TEAM-00

| Roll No | Name |
|---|---|
| ROLL-1 | Member One |
| ROLL-2 | Member Two |
| ROLL-3 | Member Three |
| ROLL-4 | Member Four |
<!--/TEAM-->

Service: Registrations (same service as Assignments 4 and 5, no new service). Code: `backend/services/registrations/`.

---

## Answers

**1. Status map (every endpoint, success and each failure, with why).**

| Endpoint | Success | Failures |
|---|---|---|
| POST `/registrations` | **201** + `Location` (a seat now exists) | 400 body not JSON; 401 no token; 415 wrong Content-Type; 422 fields wrong / unknown event / event closed / event full / key reuse; 409 already registered or same key still running; 429 too many; 503 Events unreachable (nothing created) |
| GET `/registrations` | **200** | 401; 422 bad query (`limit=0`); 429 |
| GET `/registrations/{id}` | **200** (or **304** if the ETag still matches) | 401; 404 no such registration (also someone else's); 406 cannot produce that Accept type |
| PATCH `/registrations/{id}` | **200** | 400; 401; 404; 409 not 'registered' any more; 412 stale ETag; 422 bad field |
| DELETE `/registrations/{id}` | **204** (no body) | 401; 404; 409 not cancelled yet |
| POST `.../cancellation` | **200** | 401; 404; 409 already cancelled or attended |
| POST `.../attendance` | **201** + `Location` | 401; 403 not an organizer; 404; 409 already checked in or cancelled |

The status IS the result: no failure is ever returned inside a `200`.

**2. Type catalogue** (`type` = `https://campusclub.example/problems/<key>`).

| Key | Status | Triggered by |
|---|---|---|
| `malformed-body` | 400 | body empty, not valid JSON, or not a JSON object |
| `unauthorized` | 401 | missing or empty bearer token |
| `forbidden` | 403 | a student tries to check someone in |
| `registration-not-found` | 404 | id does not exist (or belongs to another student) |
| `route-not-found` / `method-not-allowed` | 404 / 405 | unknown URL / unsupported method |
| `not-acceptable` | 406 | `Accept` asks for a type we cannot produce |
| `already-registered` | 409 | the student already holds a seat for this event |
| `illegal-transition` | 409 | cancel / edit / delete / check in in the wrong status |
| `request-in-progress` | 409 | same Idempotency-Key while the first call still runs |
| `precondition-failed` | 412 | `If-Match` ETag is stale |
| `unsupported-media-type` | 415 | body not sent as `application/json` |
| `validation-failed` | 422 | one or more fields invalid (`errors[]` lists each) |
| `unknown-event` | 422 | `event_id` does not exist |
| `event-closed` | 422 | event cancelled or already started |
| `event-full` | 422 | no seats left |
| `idempotency-key-reuse` | 422 | same key sent with a different body |
| `rate-limited` | 429 | per-client budget used up (adds `Retry-After`) |
| `internal-error` | 500 | unexpected crash (nothing internal shown) |
| `events-unavailable` | 503 | Events unreachable after retries (adds `Retry-After`) |

**3. One Problem Details body, fields labelled.**

```json
{
  "type": "https://campusclub.example/problems/illegal-transition",
  "title": "Illegal state transition",
  "status": 409,
  "detail": "Only a 'registered' registration can be cancelled (it is 'attended').",
  "instance": "/registrations/1/cancellation"
}
```
`type`: stable machine-readable id of the kind of problem. `title`: short human summary of that kind (same every time). `status`: the HTTP status, repeated in the body.
`detail`: explanation of this particular occurrence. `instance`: the URL the problem happened on. Sent with `Content-Type: application/problem+json; charset=utf-8`.

**4. A field-level 422 with two (here three) bad fields.**
Request: `POST /registrations` with `{"event_id": 0, "phone": "12", "note": "<201 characters>"}`

```json
{
  "type": "https://campusclub.example/problems/validation-failed",
  "title": "Validation failed",
  "status": 422,
  "detail": "3 field(s) failed validation.",
  "instance": "/registrations",
  "errors": [
    {"field": "event_id", "message": "must be a whole number >= 1"},
    {"field": "phone", "message": "must be 10 to 13 digits (optional leading +)"},
    {"field": "note", "message": "must be text of 200 characters or fewer"}
  ]
}
```
`validate()` collects every error first and returns them all in one response, not just the first.

**5. Which endpoints are safe to retry, and which statuses say so.**
Safe to retry: GET, HEAD, OPTIONS, PATCH, DELETE, the POST sub-resources (idempotent in effect), and `POST /registrations` *only with* the same `Idempotency-Key`.
Statuses that tell a client "transient, try again": **429** and **503** (both with `Retry-After`; 502 and network timeouts too). A 4xx (400, 401, 403, 404, 409, 422) must never be retried unchanged.
412 means "re-read the registration first, then retry".

**6. Where an internal error became a clean client error, and what was hidden.**
* Any unexpected exception in a handler becomes `500 internal-error`; the stack trace and messages (for example a MySQL error with a table name or password) are logged on the server with a request id, and the client only gets that id.
* The Events call failing (timeout, refused, 5xx after retries) becomes `503 events-unavailable`; the host, port and exception text stay in the log.
* The SMS gateway's own vocabulary (`INVALID_NUMBER`, `soap:Client`) never appears: Notifications maps it to `recipient-unreachable` / `notifications-unavailable`, and Registrations shows only `notification: "failed"` or `"pending"`.
* Another student's registration becomes `404 registration-not-found`, hiding that it exists.

**7. The same registration as JSON and as XML.** *(If your handout's question 7 continues after "and", add what it asks.)*

`Accept: application/json` (the default):
```json
{"id":1,"event_id":1,"student":"21CS001","status":"registered","ticket_code":"5DA9CBFA","note":"Vegetarian","notification":"sent","checked_in_at":null,"created_at":"2026-10-11T03:24:41Z","updated_at":"2026-10-11T03:24:41Z","links":{"self":"/registrations/1","cancellation":"/registrations/1/cancellation","attendance":"/registrations/1/attendance"}}
```
`Accept: application/xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?><registration><id>1</id><event_id>1</event_id><student>21CS001</student><status>registered</status><ticket_code>5DA9CBFA</ticket_code><note>Vegetarian</note><notification>sent</notification><checked_in_at/><created_at>2026-10-11T03:24:41Z</created_at><updated_at>2026-10-11T03:24:41Z</updated_at><links><self>/registrations/1</self><cancellation>/registrations/1/cancellation</cancellation><attendance>/registrations/1/attendance</attendance></links></registration>
```
`Accept: text/html` returns `406 not-acceptable`. (Use the values from your own `transcript.txt`.)

## D4. No regressions

The earlier behaviours still hold and are covered by tests: idempotency (`idempotent repeat returns the original`, `same key with a different body is a 422`),
timeouts, retries and back-off (`backend/tests/client.test.js`), the 304 / 412 preconditions and the rate limit. `npm test` passes all tests.

---

## Evidence (generated by `npm run evidence:a6` in `backend/`)

* `transcript.txt` (curl -v): success path (201 + Location + body) and every failure (empty or bad fields, unknown event, event full, event closed, unknown id, illegal transition, rate limit) and the XML request
* `test-output.txt`, `validator-output.txt`
