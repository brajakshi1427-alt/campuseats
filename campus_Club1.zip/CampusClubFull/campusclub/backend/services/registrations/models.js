'use strict';
// models.js - what we STORE (a registration row) versus what we PUBLISH (regJson),
// plus validate(): the hand-written replacement for the XML Schema that used to
// check requests before our code ran.

const crypto = require('crypto');
const { iso } = require('../../lib/repo');
const { fe, isInt, isStr, parsePage, unexpected } = require('../../lib/validate');

const STATUSES = ['registered', 'attended', 'cancelled'];
const PHONE = /^\+?[0-9]{10,13}$/;

// POST /registrations body. Returns ALL problems (empty list = valid).
function validate(body) {
  const errors = [];
  unexpected(body, ['event_id', 'phone', 'note'], errors);
  if (!('event_id' in body)) errors.push(fe('event_id', 'is required'));
  else if (!isInt(body.event_id) || body.event_id < 1) errors.push(fe('event_id', 'must be a whole number >= 1'));
  if (body.phone !== undefined && (!isStr(body.phone) || !PHONE.test(body.phone))) {
    errors.push(fe('phone', 'must be 10 to 13 digits (optional leading +)'));
  }
  if (body.note !== undefined && (!isStr(body.note) || body.note.length > 200)) {
    errors.push(fe('note', 'must be text of 200 characters or fewer'));
  }
  return errors;
}

function validatePatch(body) {
  const errors = [];
  unexpected(body, ['note'], errors);
  if (!('note' in body)) errors.push(fe('note', 'is required'));
  else if (!isStr(body.note) || body.note.length > 200) errors.push(fe('note', 'must be text of 200 characters or fewer'));
  return errors;
}

// ?event_id=&status=&student_ref=&sort=&limit=&offset=
function validateQuery(q) {
  const errors = [];
  const params = parsePage(q, errors);
  if (q.event_id !== undefined) {
    if (!/^\d+$/.test(String(q.event_id)) || Number(q.event_id) < 1) errors.push(fe('event_id', 'must be a whole number >= 1'));
    else params.event_id = Number(q.event_id);
  }
  if (q.status !== undefined) {
    if (!STATUSES.includes(q.status)) errors.push(fe('status', 'must be one of: ' + STATUSES.join(', ')));
    else params.status = q.status;
  }
  if (q.student_ref !== undefined) params.student_ref = String(q.student_ref);
  params.sort = q.sort === undefined ? '-created_at' : q.sort;
  if (!['created_at', '-created_at'].includes(params.sort)) errors.push(fe('sort', 'must be created_at or -created_at'));
  return { params, errors };
}

const newTicket = () => crypto.randomBytes(4).toString('hex').toUpperCase();
const fingerprint = (body) => crypto.createHash('sha256').update(JSON.stringify(Object.keys(body).sort().map((k) => [k, body[k]]))).digest('hex');

// What we publish. Differs from the stored row: no idempotency_key, request_hash,
// active_flag or version; adds links and the checked_in_at taken from the attendance table.
function regJson(row, attendance) {
  const links = { self: `/registrations/${row.registration_id}` };
  if (row.status === 'registered') {
    links.cancellation = `/registrations/${row.registration_id}/cancellation`;
    links.attendance = `/registrations/${row.registration_id}/attendance`;
  }
  return {
    id: row.registration_id,
    event_id: row.event_ref,
    student: row.student_ref,
    status: row.status,
    ticket_code: row.ticket_code,
    note: row.note || '',
    notification: row.notification_status,
    checked_in_at: attendance ? iso(attendance.checked_in_at) : null,
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
    links,
  };
}

module.exports = { STATUSES, validate, validatePatch, validateQuery, newTicket, fingerprint, regJson };
