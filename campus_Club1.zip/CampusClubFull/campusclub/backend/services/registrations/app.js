'use strict';
// CampusClub - Registrations service (REST).
// Covers Assignment 4 (resources, validation, idempotency, hardened outbound calls),
// Assignment 5 (methods, headers, ETag / If-Match / 304 / 412, CORS, rate limit) and
// Assignment 6 (honest status codes, Problem Details, field-level 422, XML).

const { send, sendEmpty, readJson, requireRole, route, optionsRoute, createService, finish, etagOf, etagMatches, checkIfMatch } = require('../../lib/http');
const { ApiError } = require('../../lib/problem');
const { nowDb, DuplicateError } = require('../../lib/repo');
const { fe, parseId } = require('../../lib/validate');
const { validate, validatePatch, validateQuery, newTicket, fingerprint, regJson } = require('./models');

// One lock per event so "count the seats, then take one" cannot interleave (single instance).
const tails = new Map();
async function withLock(key, fn) {
  const prev = tails.get(key) || Promise.resolve();
  let release;
  const gate = new Promise((r) => { release = r; });
  const mine = prev.then(() => gate);
  tails.set(key, mine);
  await prev;
  try { return await fn(); } finally { release(); if (tails.get(key) === mine) tails.delete(key); }
}

// eventsClient.getEvent(id) -> {found, event}   notifier.send({...}) -> resolves or throws
function createApp({ express, registrations, attendance, eventsClient, notifier, rateLimit, log = console }) {
  const app = createService(express, { name: 'registrations', rateLimit });
  const inflight = new Set();

  optionsRoute(app, '/registrations', 'GET, HEAD, POST, OPTIONS');
  optionsRoute(app, '/registrations/:id', 'GET, HEAD, PATCH, DELETE, OPTIONS');
  optionsRoute(app, '/registrations/:id/cancellation', 'POST, OPTIONS');
  optionsRoute(app, '/registrations/:id/attendance', 'POST, OPTIONS');

  const isStaff = (req) => ['organizer', 'admin'].includes(req.auth.role);
  const attendanceOf = async (row) => (await attendance.find({ where: [['registration_id', '=', row.registration_id]], limit: 1 }))[0] || null;
  const publish = async (row) => regJson(row, await attendanceOf(row));

  // Someone else's registration looks exactly like a missing one.
  const findVisible = async (req) => {
    const id = parseId(req.params.id, 'registration-not-found', 'registration');
    const row = await registrations.get(id);
    if (!row || (!isStaff(req) && row.student_ref !== req.auth.ref)) {
      throw new ApiError('registration-not-found', `No registration with id '${req.params.id}'.`);
    }
    return row;
  };
  const tagOf = (row) => etagOf(row.registration_id, row.version);

  // ------------------------------------------------------------------ POST /registrations
  app.post('/registrations', route(async (req, res) => {
    requireRole(req, 'student', 'organizer', 'admin');
    const body = readJson(req);

    // C4: validate FIRST, collect every error, before touching any field of the body.
    const errors = validate(body);
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });

    // C7: idempotency. Same key + same body = the original registration, no second seat.
    let key = req.headers['idempotency-key'];
    const student = req.auth.ref;
    const hash = fingerprint(body);
    if (key !== undefined) {
      key = String(key).trim();
      if (!key || key.length > 128) {
        throw new ApiError('validation-failed', 'Idempotency-Key is invalid.', { errors: [fe('Idempotency-Key', 'must be 1-128 characters')] });
      }
      const [prev] = await registrations.find({ where: [['student_ref', '=', student], ['idempotency_key', '=', key]], limit: 1 });
      if (prev) {
        if (prev.request_hash !== hash) throw new ApiError('idempotency-key-reuse', 'This Idempotency-Key was already used with a different request body.');
        return send(req, res, 201, await publish(prev), { root: 'registration', headers: { Location: `/registrations/${prev.registration_id}`, ETag: tagOf(prev), 'Cache-Control': 'no-store', 'Idempotent-Replayed': 'true' } });
      }
      if (inflight.has(`${student}:${key}`)) {
        throw new ApiError('request-in-progress', 'A request with this Idempotency-Key is still being processed.', { headers: { 'Retry-After': '1' } });
      }
      inflight.add(`${student}:${key}`);
    }

    try {
      const row = await withLock(`event:${body.event_id}`, async () => {
        // D1/D2: one hardened call to the Events service. D3 fallback: FAIL (no registration),
        // because without the event we cannot know the capacity or whether it is still open.
        let found;
        try { found = await eventsClient.getEvent(body.event_id); } catch (e) {
          log.error('events service unavailable:', e && e.message);
          throw new ApiError('events-unavailable', 'The Events service is temporarily unavailable. You were not registered; retry shortly.', { headers: { 'Retry-After': '5' } });
        }
        if (!found.found) throw new ApiError('unknown-event', `There is no event with id ${body.event_id}.`);
        const ev = found.event;
        if (ev.status !== 'open' || !ev.registration_open) throw new ApiError('event-closed', `Registration for "${ev.title}" is closed.`);

        const active = [['event_ref', '=', body.event_id], ['active_flag', '=', 1]];
        const [dup] = await registrations.find({ where: [...active, ['student_ref', '=', student]], limit: 1 });
        if (dup) throw new ApiError('already-registered', `${student} is already registered for this event.`);
        if ((await registrations.count(active)) >= ev.capacity) throw new ApiError('event-full', `"${ev.title}" has no seats left.`);

        try {
          return await registrations.insert({
            event_ref: body.event_id, student_ref: student, status: 'registered', ticket_code: newTicket(),
            note: body.note || '', idempotency_key: key || null, request_hash: hash, active_flag: 1,
            notification_status: 'skipped', version: 1, created_at: nowDb(), updated_at: nowDb(),
          }).then(async (created) => {
            // Confirmation SMS is best effort. D3 fallback here is to DEGRADE: the registration stands.
            if (!body.phone) return created;
            let state = 'sent';
            try {
              await notifier.send({
                recipient_ref: student, phone: body.phone, key: `reg-${created.registration_id}`,
                message: `You are registered for "${ev.title}". Ticket ${created.ticket_code}.`,
              });
            } catch (e) {
              log.error('confirmation not sent:', e && e.message);
              state = e && e.key === 'recipient-unreachable' ? 'failed' : 'pending';
            }
            return registrations.update(created.registration_id, { notification_status: state });
          });
        } catch (e) {
          if (e instanceof DuplicateError) throw new ApiError('already-registered', `${student} is already registered for this event.`);
          throw e;
        }
      });
      return send(req, res, 201, await publish(row), { root: 'registration', headers: { Location: `/registrations/${row.registration_id}`, ETag: tagOf(row), 'Cache-Control': 'no-store' } });
    } finally {
      if (key !== undefined) inflight.delete(`${student}:${key}`);
    }
  }));

  // ------------------------------------------------------------------ GET /registrations
  app.get('/registrations', route(async (req, res) => {
    const { params, errors } = validateQuery(req.query);
    if (errors.length) throw new ApiError('validation-failed', 'Invalid query parameters.', { errors });
    const where = [];
    if (isStaff(req)) { if (params.student_ref) where.push(['student_ref', '=', params.student_ref]); }
    else where.push(['student_ref', '=', req.auth.ref]);            // students only ever see their own
    if (params.event_id) where.push(['event_ref', '=', params.event_id]);
    if (params.status) where.push(['status', '=', params.status]);
    const orderBy = [['created_at', params.sort.startsWith('-') ? 'desc' : 'asc']];
    const [rows, total] = await Promise.all([registrations.find({ where, orderBy, limit: params.limit, offset: params.offset }), registrations.count(where)]);
    const items = await Promise.all(rows.map(publish));
    send(req, res, 200, { items, total, limit: params.limit, offset: params.offset }, { root: 'registrations', headers: { 'Cache-Control': 'no-store' } });
  }));

  // ------------------------------------------------------------------ GET /registrations/:id
  app.get('/registrations/:id', route(async (req, res) => {
    const row = await findVisible(req);
    const tag = tagOf(row);
    const cache = 'private, max-age=30, must-revalidate';
    if (etagMatches(req.headers['if-none-match'], tag, true)) return sendEmpty(req, res, 304, { ETag: tag, 'Cache-Control': cache });   // C1
    return send(req, res, 200, await publish(row), { root: 'registration', headers: { ETag: tag, 'Cache-Control': cache } });
  }));

  // ------------------------------------------------------------------ PATCH /registrations/:id
  app.patch('/registrations/:id', route(async (req, res) => {
    const row = await findVisible(req);
    checkIfMatch(req, tagOf(row), false);                                // C2 -> 412
    const body = readJson(req);
    const errors = validatePatch(body);
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });
    if (row.status !== 'registered') throw new ApiError('illegal-transition', `Only a 'registered' registration can be edited (it is '${row.status}').`);
    const updated = await registrations.update(row.registration_id, { note: body.note, version: row.version + 1, updated_at: nowDb() });
    send(req, res, 200, await publish(updated), { root: 'registration', headers: { ETag: tagOf(updated), 'Cache-Control': 'no-store' } });
  }));

  // ------------------------------------------------------------------ DELETE /registrations/:id
  app.delete('/registrations/:id', route(async (req, res) => {
    const row = await findVisible(req);
    if (row.status !== 'cancelled') throw new ApiError('illegal-transition', `Only a cancelled registration can be removed (it is '${row.status}').`);
    await registrations.remove(row.registration_id);
    sendEmpty(req, res, 204);
  }));

  // ------------------------------------------------------------------ POST .../cancellation
  app.post('/registrations/:id/cancellation', route(async (req, res) => {
    const row = await findVisible(req);
    if (row.status !== 'registered') throw new ApiError('illegal-transition', `Only a 'registered' registration can be cancelled (it is '${row.status}').`);
    const updated = await registrations.update(row.registration_id, { status: 'cancelled', active_flag: null, version: row.version + 1, updated_at: nowDb() });
    send(req, res, 200, await publish(updated), { root: 'registration', headers: { ETag: tagOf(updated), 'Cache-Control': 'no-store' } });
  }));

  // ------------------------------------------------------------------ POST .../attendance
  app.post('/registrations/:id/attendance', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const row = await findVisible(req);
    if (row.status !== 'registered') throw new ApiError('illegal-transition', `Only a 'registered' student can be checked in (it is '${row.status}').`);
    try {
      await attendance.insert({ registration_id: row.registration_id, checked_in_at: nowDb(), checked_in_by: req.auth.ref });
    } catch (e) {
      if (e instanceof DuplicateError) throw new ApiError('illegal-transition', 'This student is already checked in.');
      throw e;
    }
    const updated = await registrations.update(row.registration_id, { status: 'attended', version: row.version + 1, updated_at: nowDb() });
    send(req, res, 201, await publish(updated), { root: 'registration', headers: { Location: `/registrations/${row.registration_id}/attendance`, ETag: tagOf(updated), 'Cache-Control': 'no-store' } });
  }));

  return finish(app, log);
}

module.exports = { createApp };
