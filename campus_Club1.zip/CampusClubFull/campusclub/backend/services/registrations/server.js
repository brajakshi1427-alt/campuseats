'use strict';
require('../../lib/env');
const express = require('express');
const T = require('../../lib/tables');
const { makeRepo } = require('../../lib/repo');
const { callService, Unavailable } = require('../../lib/client');
const { ApiError } = require('../../lib/problem');
const { createApp } = require('./app');

const port = Number(process.env.REGISTRATIONS_PORT || 4003);

// Registrations -> Events: getEvent. Address from EVENTS_URL (never hard-coded).
const eventsClient = {
  async getEvent(id) {
    const r = await callService({ baseUrl: process.env.EVENTS_URL, path: `/events/${id}`, headers: { Authorization: 'Bearer service:registrations' } });
    if (r.status === 200) return { found: true, event: r.data };
    if (r.status === 404) return { found: false };
    throw new Unavailable(`unexpected answer from Events: ${r.status}`);
  },
};

// Registrations -> Notifications: sendNotification. The Idempotency-Key makes the retry safe.
const notifier = {
  async send({ recipient_ref, phone, message, key }) {
    const r = await callService({
      baseUrl: process.env.NOTIFICATIONS_URL, path: '/notifications', method: 'POST', idempotencyKey: key,
      headers: { Authorization: 'Bearer service:registrations' }, body: { recipient_ref, phone, message },
    });
    if (r.status !== 201 && r.status !== 200) {
      const type = r.data && r.data.type ? String(r.data.type).split('/').pop() : 'upstream-error';
      throw new ApiError(type === 'recipient-unreachable' ? 'recipient-unreachable' : 'notifications-unavailable', 'notification not sent');
    }
  },
};

const app = createApp({ express, registrations: makeRepo(T.registrations), attendance: makeRepo(T.attendance), eventsClient, notifier });
app.listen(port, () => console.log(`[registrations] listening on http://127.0.0.1:${port} (store: ${process.env.STORE || 'mysql'})`));
