'use strict';
const { send, readJson, requireRole, route, optionsRoute, createService, finish, etagOf, etagMatches, checkIfMatch, sendEmpty } = require('../../lib/http');
const { ApiError } = require('../../lib/problem');
const { iso, nowDb } = require('../../lib/repo');
const { fe, isInt, isStr, isIsoDate, parsePage, parseId, unexpected } = require('../../lib/validate');

const FIELDS = ['club_id', 'title', 'description', 'venue', 'starts_at', 'ends_at', 'capacity'];

function validateEvent(body, { partial = false } = {}) {
  const errors = [];
  unexpected(body, partial ? FIELDS.filter((f) => f !== 'club_id') : FIELDS, errors);
  const need = (name) => !partial || name in body;
  if (!partial && !(isInt(body.club_id) && body.club_id >= 1)) errors.push(fe('club_id', 'is required and must be a whole number >= 1'));
  if (need('title') && (!isStr(body.title) || body.title.trim().length < 3 || body.title.trim().length > 120)) {
    errors.push(fe('title', 'is required and must be 3 to 120 characters'));
  }
  if (body.description !== undefined && (!isStr(body.description) || body.description.length > 1000)) {
    errors.push(fe('description', 'must be text of 1000 characters or fewer'));
  }
  if (need('venue') && (!isStr(body.venue) || body.venue.trim().length < 2 || body.venue.trim().length > 120)) {
    errors.push(fe('venue', 'is required and must be 2 to 120 characters'));
  }
  if (need('starts_at')) {
    if (!isIsoDate(body.starts_at)) errors.push(fe('starts_at', 'is required and must be an ISO date-time, e.g. 2026-11-05T16:00:00Z'));
    else if (Date.parse(body.starts_at) <= Date.now()) errors.push(fe('starts_at', 'must be in the future'));
  }
  if (body.ends_at !== undefined) {
    if (!isIsoDate(body.ends_at)) errors.push(fe('ends_at', 'must be an ISO date-time'));
    else if (isIsoDate(body.starts_at) && Date.parse(body.ends_at) <= Date.parse(body.starts_at)) errors.push(fe('ends_at', 'must be after starts_at'));
  }
  if (need('capacity') && !(isInt(body.capacity) && body.capacity >= 1 && body.capacity <= 1000)) {
    errors.push(fe('capacity', 'is required and must be a whole number from 1 to 1000'));
  }
  return errors;
}

function eventJson(row) {
  const startsIso = iso(row.starts_at);
  return {
    id: row.event_id,
    club_id: row.club_ref,
    title: row.title,
    description: row.description || '',
    venue: row.venue,
    starts_at: startsIso,
    ends_at: iso(row.ends_at),
    capacity: row.capacity,
    status: row.status,
    registration_open: row.status === 'open' && Date.parse(startsIso) > Date.now(),
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
    links: { self: `/events/${row.event_id}` },
  };
}

// clubsClient.getClub(id) -> {found: boolean}; throws Unavailable when Clubs cannot be reached.
function createApp({ express, events, clubsClient, rateLimit }) {
  const app = createService(express, { name: 'events', rateLimit });
  optionsRoute(app, '/events', 'GET, HEAD, POST, OPTIONS');
  optionsRoute(app, '/events/:id', 'GET, HEAD, PATCH, OPTIONS');
  optionsRoute(app, '/events/:id/cancellation', 'POST, OPTIONS');

  const findEvent = async (raw) => {
    const row = await events.get(parseId(raw, 'event-not-found', 'event'));
    if (!row) throw new ApiError('event-not-found', `No event with id '${raw}'.`);
    return row;
  };

  app.get('/events', route(async (req, res) => {
    const q = req.query;
    const errors = [];
    const { limit, offset } = parsePage(q, errors);
    if (q.club_id !== undefined && !/^\d+$/.test(String(q.club_id))) errors.push(fe('club_id', 'must be an integer'));
    if (q.status !== undefined && !['open', 'cancelled'].includes(q.status)) errors.push(fe('status', 'must be open or cancelled'));
    if (q.upcoming !== undefined && !['true', 'false'].includes(q.upcoming)) errors.push(fe('upcoming', 'must be true or false'));
    if (q.sort !== undefined && !['starts_at', '-starts_at'].includes(q.sort)) errors.push(fe('sort', 'must be starts_at or -starts_at'));
    if (errors.length) throw new ApiError('validation-failed', 'Invalid query parameters.', { errors });
    const where = [];
    if (q.club_id) where.push(['club_ref', '=', Number(q.club_id)]);
    if (q.status) where.push(['status', '=', q.status]);
    if (q.upcoming === 'true') where.push(['starts_at', '>=', new Date()]);
    const sort = q.sort || 'starts_at';
    const orderBy = [['starts_at', sort.startsWith('-') ? 'desc' : 'asc']];
    const [rows, total] = await Promise.all([events.find({ where, orderBy, limit, offset }), events.count(where)]);
    send(req, res, 200, { items: rows.map(eventJson), total, limit, offset }, { root: 'events', headers: { 'Cache-Control': 'no-store' } });
  }));

  app.get('/events/:id', route(async (req, res) => {
    const row = await findEvent(req.params.id);
    const tag = etagOf(row.event_id, row.version);
    const cache = 'private, max-age=15, must-revalidate';
    if (etagMatches(req.headers['if-none-match'], tag, true)) return sendEmpty(req, res, 304, { ETag: tag, 'Cache-Control': cache });
    return send(req, res, 200, eventJson(row), { root: 'event', headers: { ETag: tag, 'Cache-Control': cache } });
  }));

  app.post('/events', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const body = readJson(req);
    const errors = validateEvent(body);
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });
    let club;
    try { club = await clubsClient.getClub(body.club_id); } catch (e) {
      throw new ApiError('clubs-unavailable', 'The Clubs service cannot be reached, so the club could not be verified. No event was created; retry shortly.',
        { headers: { 'Retry-After': '5' } });
    }
    if (!club.found) throw new ApiError('unknown-club', `There is no club with id ${body.club_id}.`);
    const row = await events.insert({
      club_ref: body.club_id, title: body.title.trim(), description: body.description || '', venue: body.venue.trim(),
      starts_at: body.starts_at, ends_at: body.ends_at || null, capacity: body.capacity, status: 'open',
      created_by: req.auth.ref, version: 1, created_at: nowDb(), updated_at: nowDb(),
    });
    send(req, res, 201, eventJson(row), { root: 'event', headers: { Location: `/events/${row.event_id}`, ETag: etagOf(row.event_id, row.version), 'Cache-Control': 'no-store' } });
  }));

  app.patch('/events/:id', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const row = await findEvent(req.params.id);
    checkIfMatch(req, etagOf(row.event_id, row.version), false);
    const body = readJson(req);
    const errors = validateEvent(body, { partial: true });
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });
    if (row.status !== 'open') throw new ApiError('illegal-transition', `A ${row.status} event cannot be edited.`);
    const changes = { updated_at: nowDb(), version: row.version + 1 };
    for (const f of ['title', 'description', 'venue', 'starts_at', 'ends_at', 'capacity']) if (f in body) changes[f] = isStr(body[f]) && f !== 'starts_at' && f !== 'ends_at' ? body[f].trim() : body[f];
    const updated = await events.update(row.event_id, changes);
    send(req, res, 200, eventJson(updated), { root: 'event', headers: { ETag: etagOf(updated.event_id, updated.version), 'Cache-Control': 'no-store' } });
  }));

  app.post('/events/:id/cancellation', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const row = await findEvent(req.params.id);
    if (row.status !== 'open') throw new ApiError('illegal-transition', `Only an open event can be cancelled (it is '${row.status}').`);
    const updated = await events.update(row.event_id, { status: 'cancelled', version: row.version + 1, updated_at: nowDb() });
    send(req, res, 200, eventJson(updated), { root: 'event', headers: { ETag: etagOf(updated.event_id, updated.version), 'Cache-Control': 'no-store' } });
  }));

  return finish(app);
}

module.exports = { createApp, validateEvent, eventJson };
