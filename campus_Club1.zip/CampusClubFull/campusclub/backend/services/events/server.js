'use strict';
require('../../lib/env');
const express = require('express');
const T = require('../../lib/tables');
const { makeRepo } = require('../../lib/repo');
const { callService } = require('../../lib/client');
const { createApp } = require('./app');

const port = Number(process.env.EVENTS_PORT || 4002);
// Events -> Clubs: checkClub. The address comes from CLUBS_URL (never hard-coded).
const clubsClient = {
  async getClub(id) {
    const r = await callService({ baseUrl: process.env.CLUBS_URL, path: `/clubs/${id}`, headers: { Authorization: 'Bearer service:events' } });
    if (r.status === 200) return { found: true };
    if (r.status === 404) return { found: false };
    throw new Error('unexpected answer from Clubs: ' + r.status);
  },
};
const app = createApp({ express, events: makeRepo(T.events), clubsClient });
app.listen(port, () => console.log(`[events] listening on http://127.0.0.1:${port} (store: ${process.env.STORE || 'mysql'})`));
