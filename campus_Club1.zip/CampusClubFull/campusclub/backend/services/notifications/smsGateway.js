'use strict';
// Adapter for the EXTERNAL SOAP SMS partner described in Assignment 3
// (WSDL: assignment3/partner.wsdl, operation sendSMS). Everything SOAP-specific stays in
// this file; the rest of CampusClub only sees our own contract and our own error words.

const { ApiError } = require('../../lib/problem');

const NS = 'http://sms.campussms.example.com/gateway/v1';
const SOAP_ACTION = `${NS}/sendSMS`;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// The request envelope: credentials in the Header, the call in the Body (matches soap-request.xml).
function buildEnvelope({ merchantId, apiKey, to, text, ref, senderId = 'CAMPUSCLB' }) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sms="${NS}">
  <soap:Header>
    <sms:AuthHeader>
      <sms:merchantId>${esc(merchantId)}</sms:merchantId>
      <sms:apiKey>${esc(apiKey)}</sms:apiKey>
    </sms:AuthHeader>
  </soap:Header>
  <soap:Body>
    <sms:SendSmsRequest>
      <sms:messageRef>${esc(ref)}</sms:messageRef>
      <sms:recipient>${esc(to)}</sms:recipient>
      <sms:text>${esc(text)}</sms:text>
      <sms:senderId>${esc(senderId)}</sms:senderId>
    </sms:SendSmsRequest>
  </soap:Body>
</soap:Envelope>`;
}

const tag = (xml, name) => {
  const m = new RegExp(`<(?:\\w+:)?${name}>([\\s\\S]*?)</(?:\\w+:)?${name}>`).exec(xml);
  return m ? m[1].trim() : null;
};

// Success response -> {ok:true,...}; soap:Fault -> {ok:false, faultcode, code, message}.
function parseResponse(xml) {
  if (/<(?:\w+:)?Fault>/.test(xml)) {
    return { ok: false, faultcode: tag(xml, 'faultcode') || '', code: tag(xml, 'code') || 'UNKNOWN', message: tag(xml, 'message') || tag(xml, 'faultstring') || '' };
  }
  if (/<(?:\w+:)?SendSmsResponse>/.test(xml)) {
    return { ok: true, messageId: tag(xml, 'gatewayMessageId'), status: tag(xml, 'status') };
  }
  return { ok: false, faultcode: 'soap:Server', code: 'UNKNOWN', message: 'unreadable response' };
}

// The partner's fault vocabulary must never reach a student: map it to OUR contract errors.
function mapFault(parsed) {
  switch (parsed.code) {
    case 'INVALID_NUMBER':
      return new ApiError('recipient-unreachable', 'The phone number could not receive the message.');
    case 'INSUFFICIENT_CREDITS':
    case 'GATEWAY_UNAVAILABLE':
      return new ApiError('notifications-unavailable', 'Notifications are temporarily unavailable; the message was not sent.', { headers: { 'Retry-After': '30' } });
    default:    // AUTH_FAILED (our credentials are wrong), anything unknown: log inside, hide outside
      return new ApiError('upstream-error', 'A dependent service returned an unexpected answer.');
  }
}

// Stand-in for the real partner (design-time only in Assignment 3): numbers ending 0000 are
// invalid, 9999 means the gateway is down, anything else succeeds.
function simulate(envelope) {
  const to = tag(envelope, 'recipient') || '';
  const ref = tag(envelope, 'messageRef') || '';
  const fault = (faultcode, code, message) => `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sms="${NS}"><soap:Body><soap:Fault>
<faultcode>${faultcode}</faultcode><faultstring>${message}</faultstring>
<detail><sms:SmsFault><sms:code>${code}</sms:code><sms:message>${message}</sms:message></sms:SmsFault></detail>
</soap:Fault></soap:Body></soap:Envelope>`;
  if (to.endsWith('0000')) return fault('soap:Client', 'INVALID_NUMBER', 'The recipient number is not valid');
  if (to.endsWith('9999')) return fault('soap:Server', 'GATEWAY_UNAVAILABLE', 'Gateway temporarily unavailable');
  return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sms="${NS}"><soap:Body><sms:SendSmsResponse>
<sms:gatewayMessageId>GW-${esc(ref)}</sms:gatewayMessageId><sms:status>ACCEPTED</sms:status><sms:segments>1</sms:segments>
<sms:processedAt>${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')}</sms:processedAt></sms:SendSmsResponse></soap:Body></soap:Envelope>`;
}

function createGateway({ url = process.env.SMS_GATEWAY_URL, merchantId = process.env.SMS_MERCHANT_ID || 'CAMPUSCLUB-001',
  apiKey = process.env.SMS_API_KEY || 'sk_test_demo', fetchImpl = globalThis.fetch, log = console } = {}) {
  return {
    // Returns {gatewayMessageId}; throws ApiError (already in OUR vocabulary) on any failure.
    async sendSms({ to, text, ref }) {
      const envelope = buildEnvelope({ merchantId, apiKey, to, text, ref });
      let xml;
      if (!url) {
        xml = simulate(envelope);
      } else {
        try {
          const res = await fetchImpl(url, {
            method: 'POST',
            headers: { 'Content-Type': 'text/xml; charset=utf-8', SOAPAction: `"${SOAP_ACTION}"` },
            body: envelope, signal: AbortSignal.timeout(Number(process.env.CALL_TIMEOUT_MS || 3000)),
          });
          xml = await res.text();
        } catch (e) {
          log.error('sms gateway unreachable:', e && e.message);
          throw new ApiError('notifications-unavailable', 'Notifications are temporarily unavailable; the message was not sent.', { headers: { 'Retry-After': '30' } });
        }
      }
      const parsed = parseResponse(xml);
      if (!parsed.ok) {
        log.error(`sms gateway fault ${parsed.faultcode} ${parsed.code}: ${parsed.message}`);
        throw mapFault(parsed);
      }
      return { gatewayMessageId: parsed.messageId };
    },
  };
}

module.exports = { buildEnvelope, parseResponse, mapFault, simulate, createGateway, SOAP_ACTION, NS };
