'use strict';
require('../../lib/env');
const express = require('express');
const T = require('../../lib/tables');
const { makeRepo } = require('../../lib/repo');
const { createApp } = require('./app');
const { createGateway } = require('./smsGateway');

const port = Number(process.env.NOTIFICATIONS_PORT || 4004);
const app = createApp({ express, notifications: makeRepo(T.notifications), gateway: createGateway() });
app.listen(port, () => console.log(`[notifications] listening on http://127.0.0.1:${port} (store: ${process.env.STORE || 'mysql'}, sms: ${process.env.SMS_GATEWAY_URL || 'simulated'})`));
