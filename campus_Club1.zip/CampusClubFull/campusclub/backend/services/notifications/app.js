'use strict';
const { send, readJson, requireRole, route, optionsRoute, createService, finish } = require('../../lib/http');
const { ApiError } = require('../../lib/problem');
const { iso, nowDb, DuplicateError } = require('../../lib/repo');
const { fe, isStr, parsePage, parseId, unexpected } = require('../../lib/validate');

const PHONE = /^\+?[0-9]{10,13}$/;

function validateNotification(body) {
  const errors = [];
  unexpected(body, ['recipient_ref', 'phone', 'message', 'channel'], errors);
  if (!isStr(body.recipient_ref) || !body.recipient_ref.trim() || body.recipient_ref.length > 40) errors.push(fe('recipient_ref', 'is required, 1 to 40 characters'));
  if (!isStr(body.phone) || !PHONE.test(body.phone)) errors.push(fe('phone', 'is required and must be 10 to 13 digits (optional leading +)'));
  if (!isStr(body.message) || !body.message.trim() || body.message.length > 300) errors.push(fe('message', 'is required, 1 to 300 characters'));
  if (body.channel !== undefined && body.channel !== 'sms') errors.push(fe('channel', "must be 'sms' (the only channel supported)"));
  return errors;
}

const mask = (phone) => phone.slice(0, 3) + '*'.repeat(Math.max(0, phone.length - 5)) + phone.slice(-2);

function notificationJson(row) {
  return {
    id: row.notification_id, recipient: row.recipient_ref, channel: row.channel, to: row.phone_masked,
    message: row.message, status: row.status, created_at: iso(row.created_at), sent_at: iso(row.sent_at),
    links: { self: `/notifications/${row.notification_id}` },
  };
}

function createApp({ express, notifications, gateway, rateLimit }) {
  const app = createService(express, { name: 'notifications', rateLimit });
  optionsRoute(app, '/notifications', 'GET, HEAD, POST, OPTIONS');
  optionsRoute(app, '/notifications/:id', 'GET, HEAD, OPTIONS');

  app.post('/notifications', route(async (req, res) => {
    requireRole(req, 'service', 'organizer', 'admin');
    const body = readJson(req);
    const errors = validateNotification(body);
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });

    const key = req.headers['idempotency-key'];
    if (key) {                                         // same key = same notification, sent once
      const [prev] = await notifications.find({ where: [['idempotency_key', '=', key]], limit: 1 });
      if (prev) return send(req, res, 201, notificationJson(prev), { root: 'notification', headers: { Location: `/notifications/${prev.notification_id}`, 'Idempotent-Replayed': 'true', 'Cache-Control': 'no-store' } });
    }
    let row;
    try {
      row = await notifications.insert({
        recipient_ref: body.recipient_ref.trim(), channel: 'sms', phone_masked: mask(body.phone),
        message: body.message, status: 'queued', idempotency_key: key || null, created_at: nowDb(),
      });
    } catch (e) {
      if (e instanceof DuplicateError) throw new ApiError('request-in-progress', 'A notification with this Idempotency-Key is being processed.', { headers: { 'Retry-After': '1' } });
      throw e;
    }
    try {
      const sent = await gateway.sendSms({ to: body.phone, text: body.message, ref: `N${row.notification_id}` });
      row = await notifications.update(row.notification_id, { status: 'sent', gateway_ref: sent.gatewayMessageId, sent_at: nowDb() });
    } catch (e) {
      await notifications.update(row.notification_id, { status: 'failed' });
      throw e;                                          // already an ApiError in our vocabulary
    }
    return send(req, res, 201, notificationJson(row), { root: 'notification', headers: { Location: `/notifications/${row.notification_id}`, 'Cache-Control': 'no-store' } });
  }));

  app.get('/notifications', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const errors = [];
    const { limit, offset } = parsePage(req.query, errors);
    if (errors.length) throw new ApiError('validation-failed', 'Invalid query parameters.', { errors });
    const where = req.query.recipient ? [['recipient_ref', '=', String(req.query.recipient)]] : [];
    const [rows, total] = await Promise.all([notifications.find({ where, orderBy: [['created_at', 'desc']], limit, offset }), notifications.count(where)]);
    send(req, res, 200, { items: rows.map(notificationJson), total, limit, offset }, { root: 'notifications', headers: { 'Cache-Control': 'no-store' } });
  }));

  app.get('/notifications/:id', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin', 'service');
    const row = await notifications.get(parseId(req.params.id, 'notification-not-found', 'notification'));
    if (!row) throw new ApiError('notification-not-found', `No notification with id '${req.params.id}'.`);
    send(req, res, 200, notificationJson(row), { root: 'notification', headers: { 'Cache-Control': 'no-store' } });
  }));

  return finish(app);
}

module.exports = { createApp, validateNotification, mask };
