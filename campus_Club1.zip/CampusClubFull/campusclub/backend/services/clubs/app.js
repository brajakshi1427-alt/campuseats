'use strict';
const { send, sendEmpty, readJson, requireRole, route, optionsRoute, createService, finish } = require('../../lib/http');
const { ApiError } = require('../../lib/problem');
const { iso, nowDb, DuplicateError } = require('../../lib/repo');
const { fe, isStr, parsePage, parseId, unexpected } = require('../../lib/validate');

const CATEGORIES = ['technical', 'cultural', 'sports', 'literary', 'social', 'other'];

function validateClub(body) {
  const errors = [];
  unexpected(body, ['name', 'description', 'category'], errors);
  if (!isStr(body.name) || body.name.trim().length < 3 || body.name.trim().length > 100) {
    errors.push(fe('name', 'is required and must be 3 to 100 characters'));
  }
  if (body.description !== undefined && (!isStr(body.description) || body.description.length > 500)) {
    errors.push(fe('description', 'must be text of 500 characters or fewer'));
  }
  if (body.category !== undefined && !CATEGORIES.includes(body.category)) {
    errors.push(fe('category', 'must be one of: ' + CATEGORIES.join(', ')));
  }
  return errors;
}

async function clubJson(row, members) {
  return {
    id: row.club_id,
    name: row.name,
    description: row.description || '',
    category: row.category,
    president: row.president_ref,
    member_count: await members.count([['club_id', '=', row.club_id]]),
    created_at: iso(row.created_at),
    links: { self: `/clubs/${row.club_id}`, members: `/clubs/${row.club_id}/members` },
  };
}

function createApp({ express, clubs, members, rateLimit }) {
  const app = createService(express, { name: 'clubs', rateLimit });
  optionsRoute(app, '/clubs', 'GET, HEAD, POST, OPTIONS');
  optionsRoute(app, '/clubs/:id', 'GET, HEAD, OPTIONS');
  optionsRoute(app, '/clubs/:id/memberships', 'POST, OPTIONS');
  optionsRoute(app, '/clubs/:id/memberships/me', 'DELETE, OPTIONS');
  optionsRoute(app, '/clubs/:id/members', 'GET, HEAD, OPTIONS');

  const findClub = async (raw) => {
    const row = await clubs.get(parseId(raw, 'club-not-found', 'club'));
    if (!row || !row.is_active) throw new ApiError('club-not-found', `No club with id '${raw}'.`);
    return row;
  };

  app.get('/clubs', route(async (req, res) => {
    const errors = [];
    const { limit, offset } = parsePage(req.query, errors);
    if (req.query.category !== undefined && !CATEGORIES.includes(req.query.category)) {
      errors.push(fe('category', 'must be one of: ' + CATEGORIES.join(', ')));
    }
    if (errors.length) throw new ApiError('validation-failed', 'Invalid query parameters.', { errors });
    const where = [['is_active', '=', 1]];
    if (req.query.category) where.push(['category', '=', req.query.category]);
    if (req.query.q) where.push(['name', 'like', String(req.query.q)]);
    const [rows, total] = await Promise.all([
      clubs.find({ where, orderBy: [['name', 'asc']], limit, offset }), clubs.count(where)]);
    const items = await Promise.all(rows.map((r) => clubJson(r, members)));
    send(req, res, 200, { items, total, limit, offset }, { root: 'clubs', headers: { 'Cache-Control': 'no-store' } });
  }));

  app.get('/clubs/:id', route(async (req, res) => {
    const row = await findClub(req.params.id);
    send(req, res, 200, await clubJson(row, members), { root: 'club', headers: { 'Cache-Control': 'private, max-age=30' } });
  }));

  app.post('/clubs', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin');
    const body = readJson(req);
    const errors = validateClub(body);
    if (errors.length) throw new ApiError('validation-failed', `${errors.length} field(s) failed validation.`, { errors });
    let row;
    try {
      row = await clubs.insert({
        name: body.name.trim(), description: body.description || '', category: body.category || 'other',
        president_ref: req.auth.ref, is_active: 1, created_at: nowDb(),
      });
    } catch (e) {
      if (e instanceof DuplicateError) {
        throw new ApiError('validation-failed', '1 field(s) failed validation.', { errors: [fe('name', 'a club with this name already exists')] });
      }
      throw e;
    }
    send(req, res, 201, await clubJson(row, members), { root: 'club', headers: { Location: `/clubs/${row.club_id}`, 'Cache-Control': 'no-store' } });
  }));

  app.post('/clubs/:id/memberships', route(async (req, res) => {
    requireRole(req, 'student', 'organizer', 'admin');
    const club = await findClub(req.params.id);
    let row;
    try {
      row = await members.insert({ club_id: club.club_id, student_ref: req.auth.ref, role: 'member', joined_at: nowDb() });
    } catch (e) {
      if (e instanceof DuplicateError) throw new ApiError('already-member', `${req.auth.ref} is already a member of this club.`);
      throw e;
    }
    send(req, res, 201, { club_id: club.club_id, student_ref: row.student_ref, role: row.role, joined_at: iso(row.joined_at) },
      { root: 'membership', headers: { Location: `/clubs/${club.club_id}/memberships/me`, 'Cache-Control': 'no-store' } });
  }));

  app.delete('/clubs/:id/memberships/me', route(async (req, res) => {
    const club = await findClub(req.params.id);
    const [mine] = await members.find({ where: [['club_id', '=', club.club_id], ['student_ref', '=', req.auth.ref]], limit: 1 });
    if (!mine) throw new ApiError('membership-not-found', 'You are not a member of this club.');
    await members.remove(mine.member_id);
    sendEmpty(req, res, 204);
  }));

  app.get('/clubs/:id/members', route(async (req, res) => {
    requireRole(req, 'organizer', 'admin', 'service');
    const club = await findClub(req.params.id);
    const errors = [];
    const { limit, offset } = parsePage(req.query, errors);
    if (errors.length) throw new ApiError('validation-failed', 'Invalid query parameters.', { errors });
    const where = [['club_id', '=', club.club_id]];
    const [rows, total] = await Promise.all([members.find({ where, orderBy: [['joined_at', 'asc']], limit, offset }), members.count(where)]);
    const items = rows.map((m) => ({ student_ref: m.student_ref, role: m.role, joined_at: iso(m.joined_at) }));
    send(req, res, 200, { items, total, limit, offset }, { root: 'members', headers: { 'Cache-Control': 'no-store' } });
  }));

  return finish(app);
}

module.exports = { createApp, validateClub, CATEGORIES };
