'use strict';
require('../../lib/env');
const express = require('express');
const T = require('../../lib/tables');
const { makeRepo } = require('../../lib/repo');
const { createApp } = require('./app');

const port = Number(process.env.CLUBS_PORT || 4001);
const app = createApp({ express, clubs: makeRepo(T.clubs), members: makeRepo(T.club_members) });
app.listen(port, () => console.log(`[clubs] listening on http://127.0.0.1:${port} (store: ${process.env.STORE || 'mysql'})`));
