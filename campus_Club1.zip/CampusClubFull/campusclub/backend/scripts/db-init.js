'use strict';
// Creates the MySQL database, the tables (db/schema.sql) and demo data (db/seed.sql).
//   node scripts/db-init.js            create what is missing, load demo data if empty
//   node scripts/db-init.js --reset    DROP all CampusClub tables first, then rebuild
require('../lib/env');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

(async () => {
  const dbName = process.env.DB_NAME || 'campusclub';
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '', multipleStatements: true,
  });
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await conn.query(`USE \`${dbName}\``);
  if (process.argv.includes('--reset')) {
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const t of ['attendance', 'registrations', 'notifications', 'events', 'club_members', 'clubs']) await conn.query(`DROP TABLE IF EXISTS \`${t}\``);
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');
    console.log('dropped all CampusClub tables');
  }
  await conn.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
  console.log('tables ready');
  const [[{ n }]] = await conn.query('SELECT COUNT(*) AS n FROM clubs');
  if (n === 0) {
    await conn.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'seed.sql'), 'utf8'));
    console.log('demo data loaded (5 clubs, 6 events)');
  } else {
    console.log('clubs already present; demo data not loaded again (use --reset to start over)');
  }
  await conn.end();
})().catch((e) => { console.error('db:init failed:', e.message); process.exit(1); });
