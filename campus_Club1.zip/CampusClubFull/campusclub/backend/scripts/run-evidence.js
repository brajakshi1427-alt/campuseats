'use strict';
// ONE command that produces the evidence files for an assignment.
//   node scripts/run-evidence.js <i|v> <transcript-name> <output-folder> [--memory]
// Examples (also available as npm scripts):
//   npm run evidence:a4      -> ../assignment4  (curl -i, curl-transcript.txt)
//   npm run evidence:a5      -> ../assignment5  (curl -v, curl-transcript.txt)
//   npm run evidence:a6      -> ../assignment6  (curl -v, transcript.txt)
// Add --memory to run without MySQL (nothing is saved; good for a quick check).
require('../lib/env');
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const memory = process.argv.includes('--memory');
const [mode = 'v', transcriptName = 'transcript.txt', outDir = '../assignment6'] = args;
const root = path.join(__dirname, '..');
const out = path.resolve(root, outDir);
fs.mkdirSync(out, { recursive: true });
const env = { ...process.env, RATE_LIMIT: '60', ...(memory ? { STORE: 'memory' } : {}) };

console.log('1/4 running the tests ...');
const tests = spawnSync(process.execPath, ['--test'], { cwd: root, encoding: 'utf8', env });
fs.writeFileSync(path.join(out, 'test-output.txt'), (tests.stdout || '') + (tests.stderr || ''), 'utf8');
const summary = (tests.stdout || '').split('\n').filter((l) => /^# (tests|pass|fail)/.test(l)).join('  ');
console.log('    ', summary || '(see test-output.txt)');

console.log('2/4 validating openapi.yaml ...');
const swagger = path.join(root, 'node_modules', '.bin', process.platform === 'win32' ? 'swagger-cli.cmd' : 'swagger-cli');
let validatorText;
if (fs.existsSync(swagger)) {
  const v = spawnSync(swagger, ['validate', 'services/registrations/openapi.yaml'], { cwd: root, encoding: 'utf8', shell: process.platform === 'win32' });
  validatorText = (v.stdout || '') + (v.stderr || '');
  console.log('    ', v.status === 0 ? 'OK, no errors' : 'PROBLEM - open validator-output.txt');
} else {
  validatorText = 'swagger-cli is not installed. Run "npm install" first (it is a devDependency), then run this again.\n';
  console.log('    swagger-cli missing: run npm install');
}
fs.writeFileSync(path.join(out, 'validator-output.txt'), validatorText, 'utf8');

console.log(`3/4 starting the services (store: ${memory ? 'memory' : env.STORE || 'mysql'}) ...`);
const server = spawn(process.execPath, [path.join(__dirname, 'start-all.js')], { cwd: root, env, stdio: 'ignore' });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  try {
    for (const port of [4001, 4002, 4003, 4004]) {
      let up = false;
      for (let i = 0; i < 40 && !up; i += 1) {
        try { up = (await fetch(`http://127.0.0.1:${port}/health`)).ok; } catch (e) { await wait(500); }
      }
      if (!up) throw new Error(`The service on port ${port} did not start. Run "npm start" by hand to see the error (is MySQL running? did you run "npm run db:init"?).`);
    }
    console.log('4/4 recording the curl transcript ...');
    const t = spawnSync(process.execPath, [path.join(__dirname, 'make-transcript.js'), mode, path.join(out, transcriptName)], { cwd: root, env, stdio: 'inherit' });
    if (t.status !== 0) throw new Error('make-transcript.js failed');
    console.log(`\nDone. Created in ${out}:\n  test-output.txt, validator-output.txt, ${transcriptName}`);
  } catch (e) {
    console.error('\n' + e.message);
    process.exitCode = 1;
  } finally {
    if (process.platform === 'win32') spawnSync('taskkill', ['/pid', String(server.pid), '/T', '/F'], { stdio: 'ignore' });
    else server.kill();
  }
})();
