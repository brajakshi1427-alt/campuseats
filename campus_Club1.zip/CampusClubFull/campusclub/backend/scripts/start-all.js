'use strict';
// Starts all four services (Clubs 4001, Events 4002, Registrations 4003, Notifications 4004).
require('../lib/env');
const { spawn } = require('child_process');
const path = require('path');

const services = ['clubs', 'events', 'registrations', 'notifications'];
// Each service finds the others through environment variables (never hard-coded in the services).
// Unless .env already sets them, they are derived here from the port numbers.
const env = { ...process.env };
env.CLUBS_URL = env.CLUBS_URL || `http://127.0.0.1:${env.CLUBS_PORT || 4001}`;
env.EVENTS_URL = env.EVENTS_URL || `http://127.0.0.1:${env.EVENTS_PORT || 4002}`;
env.NOTIFICATIONS_URL = env.NOTIFICATIONS_URL || `http://127.0.0.1:${env.NOTIFICATIONS_PORT || 4004}`;
const children = services.map((name) => {
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'services', name, 'server.js')], { env });
  const tag = `[${name}]`.padEnd(16);
  child.stdout.on('data', (d) => String(d).split('\n').filter(Boolean).forEach((l) => console.log(l.startsWith('[') ? l : `${tag}${l}`)));
  child.stderr.on('data', (d) => String(d).split('\n').filter(Boolean).forEach((l) => console.error(`${tag}${l}`)));
  child.on('exit', (code) => { if (code) console.error(`${tag}stopped with code ${code}`); });
  return child;
});
const stop = () => { children.forEach((c) => c.kill()); process.exit(0); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
console.log('CampusClub services starting. Press Ctrl+C to stop.');
