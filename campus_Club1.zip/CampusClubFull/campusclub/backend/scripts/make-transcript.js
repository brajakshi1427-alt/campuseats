'use strict';
// Runs REAL curl commands against the running services and saves everything to transcript.txt
// (success path + every failure path). Usage:  node scripts/make-transcript.js [i|v] [outfile]
//   i = curl -i (Assignment 4)      v = curl -v (Assignments 5 and 6)
const { spawnSync } = require('child_process');
const fs = require('fs');

const MODE = process.argv[2] === 'i' ? 'i' : 'v';
const OUT = process.argv[3] || 'transcript.txt';
const REG = process.env.REGISTRATIONS_BASE || 'http://127.0.0.1:4003';
const EVT = process.env.EVENTS_BASE || 'http://127.0.0.1:4002';
const CLB = process.env.CLUBS_BASE || 'http://127.0.0.1:4001';
const CURL = process.platform === 'win32' ? 'curl.exe' : 'curl';
const FLAG = MODE === 'v' ? '-v' : '-i';
const J = 'Content-Type: application/json';
const out = [`CampusClub Registrations - curl transcript (${new Date().toISOString()})`, `mode: curl ${FLAG}`];

function curl(method, url, headers = [], body, flag = FLAG) {
  const args = ['-s', flag, '-X', method, url];
  let shown = `curl ${flag} -X ${method} ${url}`;
  for (const h of headers) { args.push('-H', h); shown += ` -H "${h.replace(/"/g, '\\"')}"`; }
  if (body !== undefined) { const d = typeof body === 'string' ? body : JSON.stringify(body); args.push('-d', d); shown += ` -d '${d}'`; }
  const r = spawnSync(CURL, args, { encoding: 'utf8' });
  if (r.error) { console.error('curl could not be started:', r.error.message); process.exit(1); }
  return { shown, text: (r.stderr || '') + (r.stdout || '') };
}
function step(title, method, path, headers, body) {
  const r = curl(method, REG + path, headers, body);
  out.push(`\n${'='.repeat(78)}\n## ${title}\n$ ${r.shown}\n${'-'.repeat(78)}\n${r.text}`);
  console.log('done:', title);
  return r.text;
}
const quiet = (method, url, headers, body) => curl(method, url, headers, body, '-s').text;     // setup, not logged
const json = (t) => { try { return JSON.parse(t); } catch (e) { return {}; } };
const etag = (t) => { const m = /^[<\s]*etag:\s*("[^"]+")/im.exec(t); return m ? m[1] : '"missing"'; };

const ORG = 'Authorization: Bearer organizer:21CS010';
const S1 = 'Authorization: Bearer student:21CS001';
const S2 = 'Authorization: Bearer student:21CS002';
const S3 = 'Authorization: Bearer student:21CS003';
const when = (days) => new Date(Date.now() + days * 864e5).toISOString().replace(/\.\d{3}Z$/, 'Z');

// ---- setup (not part of the transcript): a club and two events with a tiny capacity ----
const club = json(quiet('POST', CLB + '/clubs', [J, ORG], { name: 'Demo Club ' + Date.now(), category: 'technical' }));
if (!club.id) { console.error('Setup failed: is the Clubs service running on', CLB, '?'); process.exit(1); }
const ev = json(quiet('POST', EVT + '/events', [J, ORG], { club_id: club.id, title: 'Hack Night', venue: 'Lab 2', starts_at: when(5), capacity: 2 }));
const evClosed = json(quiet('POST', EVT + '/events', [J, ORG], { club_id: club.id, title: 'Cancelled Workshop', venue: 'Hall', starts_at: when(6), capacity: 5 }));
if (!ev.id || !evClosed.id) { console.error('Setup failed: could not create events', ev, evClosed); process.exit(1); }
quiet('POST', `${EVT}/events/${evClosed.id}/cancellation`, [ORG]);

// ---- success paths ----
step('1. SUCCESS: register for an event (201 + Location)', 'POST', '/registrations', [J, S1, 'Idempotency-Key: demo-key-001'], { event_id: ev.id, phone: '9876543210', note: 'Vegetarian' });
step('2. IDEMPOTENT REPEAT: same body + same Idempotency-Key returns the original', 'POST', '/registrations', [J, S1, 'Idempotency-Key: demo-key-001'], { event_id: ev.id, phone: '9876543210', note: 'Vegetarian' });
const read = step('3. READ one registration (200 + ETag + Cache-Control)', 'GET', '/registrations/1', [S1]);
const tag = etag(read);
step('4. CONDITIONAL GET: If-None-Match with the current ETag -> 304 Not Modified', 'GET', '/registrations/1', [S1, `If-None-Match: ${tag}`]);
step('5. CONDITIONAL WRITE: PATCH with the current ETag -> 200 and a new ETag', 'PATCH', '/registrations/1', [J, S1, `If-Match: ${tag}`], { note: 'Vegan' });
step('6. CONDITIONAL WRITE with the OLD ETag -> 412 Precondition Failed', 'PATCH', '/registrations/1', [J, S1, `If-Match: ${tag}`], { note: 'Jain' });
step('7. LIST with a query string (filter + sort + page)', 'GET', `/registrations?event_id=${ev.id}&status=registered&sort=-created_at&limit=5&offset=0`, [ORG]);
step('8. CONTENT NEGOTIATION: Accept: application/xml', 'GET', '/registrations/1', [S1, 'Accept: application/xml']);
step('9. OPTIONS: the Allow header lists the methods', 'OPTIONS', '/registrations/1', []);
step('10. CORS PREFLIGHT from another origin (the React app)', 'OPTIONS', '/registrations', ['Origin: http://localhost:5173', 'Access-Control-Request-Method: POST', 'Access-Control-Request-Headers: authorization, content-type, idempotency-key']);
step('11. METHOD OVERRIDE fallback: POST + X-HTTP-Method-Override: PATCH', 'POST', '/registrations/1', [J, S1, 'X-HTTP-Method-Override: PATCH'], { note: 'Via override' });
step('12. DEGRADED but successful: the SMS gateway is down (number ends 9999), the registration still succeeds with notification: pending', 'POST', '/registrations', [J, S2], { event_id: ev.id, phone: '9876549999' });

// ---- failure paths ----
step('13. FAILURE 400: malformed JSON', 'POST', '/registrations', [J, S3], '{"event_id": [');
step('14. FAILURE 422: three bad fields at once (field-level errors[])', 'POST', '/registrations', [J, S3], { event_id: 0, phone: '12', note: 'x'.repeat(201) });
step('15. FAILURE 422: unknown event', 'POST', '/registrations', [J, S3], { event_id: 999999 });
step('16. FAILURE 409: already registered for this event', 'POST', '/registrations', [J, S1], { event_id: ev.id });
step('17. FAILURE 422: event is full (capacity 2, two seats taken)', 'POST', '/registrations', [J, S3], { event_id: ev.id });
step('18. FAILURE 422: event closed (it was cancelled)', 'POST', '/registrations', [J, S3], { event_id: evClosed.id });
step('19. FAILURE 422: Idempotency-Key reused with a DIFFERENT body', 'POST', '/registrations', [J, S1, 'Idempotency-Key: demo-key-001'], { event_id: ev.id, note: 'Something else' });
step('20. FAILURE 404: unknown registration id', 'GET', '/registrations/999999', [S1]);
step('21. FAILURE 404: someone else\'s registration looks missing', 'GET', '/registrations/1', [S3]);
step('22. FAILURE 401: no Authorization header', 'GET', '/registrations', []);
step('23. FAILURE 406: Accept: text/html', 'GET', '/registrations/1', [S1, 'Accept: text/html']);
step('24. FAILURE 415: body sent as text/plain', 'POST', '/registrations', ['Content-Type: text/plain', S3], 'event_id=1');
step('25. FAILURE 403: a student tries to check someone in', 'POST', '/registrations/1/attendance', [S1]);
step('26. STATE CHANGE: the organizer checks the student in (201 + Location)', 'POST', '/registrations/1/attendance', [ORG]);
step('27. FAILURE 409: cancel a registration that is already attended (illegal-transition)', 'POST', '/registrations/1/cancellation', [S1]);
step('28. cancel a registration that is still registered (200)', 'POST', '/registrations/2/cancellation', [S2]);
step('29. FAILURE 409: cancel it again', 'POST', '/registrations/2/cancellation', [S2]);
step('30. DELETE the cancelled registration (204, no body)', 'DELETE', '/registrations/2', [S2]);
step('31. FAILURE 404: it is gone', 'GET', '/registrations/2', [S2]);

// ---- rate limit (a separate client so the rest is not disturbed) ----
const burst = ['Authorization: Bearer student:burst-client'];
step('32. RATE LIMIT: first request of a fresh client (note the X-RateLimit headers)', 'GET', '/registrations', burst);
for (let i = 0; i < 400; i += 1) {
  const r = curl('GET', REG + '/registrations', burst);
  if (/HTTP\/1\.1 429/.test(r.text)) {
    out.push(`\n${'='.repeat(78)}\n## 33. FAILURE 429: budget exceeded (note Retry-After)\n$ ${r.shown}\n${'-'.repeat(78)}\n${r.text}`);
    console.log('done: 33. 429');
    break;
  }
}
fs.writeFileSync(OUT, out.join('\n') + '\n', 'utf8');
console.log(`\nSaved ${OUT}`);
