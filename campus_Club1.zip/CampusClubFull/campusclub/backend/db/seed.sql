-- Demo data for CampusClub (loaded by "npm run db:init" when the clubs table is empty).
INSERT INTO clubs (name, description, category, president_ref, is_active, created_at) VALUES
 ('Coding Club',       'Weekly hack nights, DSA practice and open-source sprints.', 'technical', '21CS010', 1, UTC_TIMESTAMP()),
 ('Robotics Society',  'Build robots, drones and IoT gadgets.',                     'technical', '21EC004', 1, UTC_TIMESTAMP()),
 ('Dramatics Club',    'Street plays, stage productions and improv.',               'cultural',  '21ME022', 1, UTC_TIMESTAMP()),
 ('Cricket Club',      'Practice sessions and inter-college tournaments.',          'sports',    '21CE015', 1, UTC_TIMESTAMP()),
 ('Literary Society',  'Debates, poetry slams and the college magazine.',           'literary',  '21IT007', 1, UTC_TIMESTAMP());

INSERT INTO club_members (club_id, student_ref, role, joined_at) VALUES
 (1, '21CS010', 'president', UTC_TIMESTAMP()), (1, '21CS001', 'member', UTC_TIMESTAMP()),
 (2, '21EC004', 'president', UTC_TIMESTAMP()), (3, '21ME022', 'president', UTC_TIMESTAMP()),
 (4, '21CE015', 'president', UTC_TIMESTAMP()), (5, '21IT007', 'president', UTC_TIMESTAMP());

INSERT INTO events (club_ref, title, description, venue, starts_at, ends_at, capacity, status, created_by, version, created_at, updated_at) VALUES
 (1, 'Hack Night: Build a REST API', 'Pair up and build a small Express API in three hours.', 'Computer Lab 2',
     UTC_TIMESTAMP() + INTERVAL 3 DAY,  UTC_TIMESTAMP() + INTERVAL 3 DAY + INTERVAL 3 HOUR, 40, 'open', '21CS010', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
 (1, 'DSA Contest',                 'Timed problem solving, prizes for the top three.',     'Seminar Hall',
     UTC_TIMESTAMP() + INTERVAL 10 DAY, UTC_TIMESTAMP() + INTERVAL 10 DAY + INTERVAL 2 HOUR, 100, 'open', '21CS010', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
 (2, 'Line Follower Workshop',      'Build and race your first line-following robot.',      'Robotics Lab',
     UTC_TIMESTAMP() + INTERVAL 5 DAY,  UTC_TIMESTAMP() + INTERVAL 5 DAY + INTERVAL 4 HOUR, 25, 'open', '21EC004', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
 (3, 'Street Play: Mukhauta',       'Open auditions and a live performance in the quad.',   'Main Quad',
     UTC_TIMESTAMP() + INTERVAL 7 DAY,  UTC_TIMESTAMP() + INTERVAL 7 DAY + INTERVAL 2 HOUR, 150, 'open', '21ME022', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
 (4, 'Inter-Department Cricket',    'Knockout tournament, teams of 11.',                    'College Ground',
     UTC_TIMESTAMP() + INTERVAL 14 DAY, UTC_TIMESTAMP() + INTERVAL 14 DAY + INTERVAL 6 HOUR, 22, 'open', '21CE015', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP()),
 (5, 'Open Mic and Poetry Slam',    'Bring your own poem, story or stand-up.',              'Auditorium',
     UTC_TIMESTAMP() + INTERVAL 6 DAY,  UTC_TIMESTAMP() + INTERVAL 6 DAY + INTERVAL 2 HOUR, 80, 'open', '21IT007', 1, UTC_TIMESTAMP(), UTC_TIMESTAMP());
