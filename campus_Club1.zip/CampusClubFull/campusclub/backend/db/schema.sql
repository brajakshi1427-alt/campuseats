-- CampusClub database schema (MySQL 8). One block per service.
-- Rule: a table belongs to exactly ONE service; foreign keys never cross a service boundary.
-- club_ref, event_ref and student_ref are plain values that name something another service owns. They are NOT foreign keys: no table belongs to two services.

CREATE DATABASE IF NOT EXISTS campusclub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campusclub;

-- ======================================================================
-- Clubs service
-- ======================================================================

CREATE TABLE IF NOT EXISTS clubs (
    club_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(500) NOT NULL,
    category VARCHAR(20) NOT NULL,
    president_ref VARCHAR(40) NOT NULL,
    is_active TINYINT(1) NOT NULL,
    created_at DATETIME NOT NULL,
    UNIQUE (name),
    CHECK (category IN ('technical','cultural','sports','literary','social','other'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS club_members (
    member_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    club_id BIGINT NOT NULL,
    student_ref VARCHAR(40) NOT NULL,
    role VARCHAR(20) NOT NULL,
    joined_at DATETIME NOT NULL,
    FOREIGN KEY (club_id) REFERENCES clubs(club_id),
    UNIQUE (club_id, student_ref),
    CHECK (role IN ('member','lead','president'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================================
-- Events service
-- ======================================================================

CREATE TABLE IF NOT EXISTS events (
    event_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    club_ref BIGINT NOT NULL,
    title VARCHAR(120) NOT NULL,
    description VARCHAR(1000) NOT NULL,
    venue VARCHAR(120) NOT NULL,
    starts_at DATETIME NOT NULL,
    ends_at DATETIME NULL,
    capacity INT NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_by VARCHAR(40) NOT NULL,
    version INT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CHECK (capacity BETWEEN 1 AND 1000),
    CHECK (status IN ('open','cancelled')),
    INDEX idx_events_starts (starts_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================================
-- Registrations service
-- ======================================================================

CREATE TABLE IF NOT EXISTS registrations (
    registration_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_ref BIGINT NOT NULL,
    student_ref VARCHAR(40) NOT NULL,
    status VARCHAR(20) NOT NULL,
    ticket_code VARCHAR(12) NOT NULL,
    note VARCHAR(200) NOT NULL,
    idempotency_key VARCHAR(128) NULL,
    request_hash CHAR(64) NOT NULL,
    active_flag TINYINT NULL,
    notification_status VARCHAR(20) NOT NULL,
    version INT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE (student_ref, idempotency_key),
    UNIQUE (event_ref, student_ref, active_flag),
    CHECK (status IN ('registered','attended','cancelled')),
    CHECK (notification_status IN ('skipped','sent','pending','failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS attendance (
    attendance_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    registration_id BIGINT NOT NULL,
    checked_in_at DATETIME NOT NULL,
    checked_in_by VARCHAR(40) NOT NULL,
    FOREIGN KEY (registration_id) REFERENCES registrations(registration_id),
    UNIQUE (registration_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================================
-- Notifications service
-- ======================================================================

CREATE TABLE IF NOT EXISTS notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    recipient_ref VARCHAR(40) NOT NULL,
    channel VARCHAR(10) NOT NULL,
    phone_masked VARCHAR(20) NOT NULL,
    message VARCHAR(300) NOT NULL,
    status VARCHAR(20) NOT NULL,
    gateway_ref VARCHAR(60) NULL,
    idempotency_key VARCHAR(128) NULL,
    created_at DATETIME NOT NULL,
    sent_at DATETIME NULL,
    UNIQUE (idempotency_key),
    CHECK (status IN ('queued','sent','failed'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
