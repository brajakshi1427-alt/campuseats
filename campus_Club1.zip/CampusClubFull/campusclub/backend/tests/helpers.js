'use strict';
const express = require('express');

async function listen(app) {
  return new Promise((resolve) => {
    const server = app.listen(0, '127.0.0.1', () => resolve({ server, base: `http://127.0.0.1:${server.address().port}` }));
  });
}

// api(base)(method, path, {token, headers, body, raw}) -> {status, headers, json, text}
const api = (base) => async (method, path, { token = 'student:21CS001', headers = {}, body, raw } = {}) => {
  const h = { ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload = raw;
  if (body !== undefined) { payload = JSON.stringify(body); h['Content-Type'] = 'application/json'; }
  else if (raw !== undefined && !h['Content-Type']) h['Content-Type'] = 'application/json';
  const res = await fetch(base + path, { method, headers: h, body: payload });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch (e) { json = null; }
  return { status: res.status, headers: res.headers, json, text };
};

module.exports = { express, listen, api };
