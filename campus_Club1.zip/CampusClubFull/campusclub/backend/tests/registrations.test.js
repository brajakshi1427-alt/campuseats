'use strict';
// The four tests required by Assignment 4 (C8), then the extra Assignment 5 / 6 checks.
const test = require('node:test');
const assert = require('node:assert/strict');
const zlib = require('node:zlib');
const { express, listen, api } = require('./helpers');
const T = require('../lib/tables');
const { MemoryRepo } = require('../lib/repo');
const { createApp } = require('../services/registrations/app');

const future = new Date(Date.now() + 7 * 864e5).toISOString();
const makeEvent = (over = {}) => ({ id: 1, club_id: 1, title: 'Hack Night', status: 'open', registration_open: true, capacity: 2, starts_at: future, ...over });
const silent = { error() {} };

async function setup({ event = makeEvent(), notify, events, rateLimit } = {}) {
  const calls = { events: 0, notify: [] };
  const eventsClient = events || {
    async getEvent(id) { calls.events += 1; return id === 1 ? { found: true, event: event } : { found: false }; },
  };
  const notifier = notify || { async send(m) { calls.notify.push(m); } };
  const registrations = new MemoryRepo(T.registrations);
  const attendance = new MemoryRepo(T.attendance);
  const app = createApp({ express, registrations, attendance, eventsClient, notifier, rateLimit, log: silent });
  const { server, base } = await listen(app);
  return { call: api(base), calls, close: () => server.close() };
}
const GOOD = { event_id: 1 };

// ---------------- Assignment 4 (C8): the four required tests ----------------
test('create returns 201 with a Location header', async () => {
  const s = await setup();
  const r = await s.call('POST', '/registrations', { body: GOOD });
  assert.equal(r.status, 201);
  assert.equal(r.headers.get('location'), '/registrations/1');
  assert.equal(r.json.status, 'registered');
  assert.equal(r.json.student, '21CS001');
  for (const hidden of ['idempotency_key', 'request_hash', 'active_flag', 'version']) assert.ok(!(hidden in r.json), hidden + ' must not leak');
  s.close();
});

test('idempotent repeat returns the original and takes only one seat', async () => {
  const s = await setup();
  const h = { 'Idempotency-Key': 'abc-123' };
  const first = await s.call('POST', '/registrations', { body: GOOD, headers: h });
  const again = await s.call('POST', '/registrations', { body: GOOD, headers: h });
  assert.equal(again.status, 201);
  assert.deepEqual(again.json, first.json);
  assert.equal(again.headers.get('idempotent-replayed'), 'true');
  const list = await s.call('GET', '/registrations', { token: 'organizer:21CS010' });
  assert.equal(list.json.total, 1);
  s.close();
});

test('a bad body returns 422 with field-level errors', async () => {
  const s = await setup();
  const r = await s.call('POST', '/registrations', { body: { event_id: 0 } });
  assert.equal(r.status, 422);
  assert.match(r.headers.get('content-type'), /^application\/problem\+json/);
  assert.equal(r.json.errors[0].field, 'event_id');
  s.close();
});

test('an unknown id returns 404', async () => {
  const s = await setup();
  const r = await s.call('GET', '/registrations/999');
  assert.equal(r.status, 404);
  assert.ok(r.json.type.endsWith('/registration-not-found'));
  s.close();
});

// ---------------- Assignment 5: methods, headers, caching, preconditions ----------------
test('ETag then 304 on a conditional GET', async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  const first = await s.call('GET', '/registrations/1');
  const tag = first.headers.get('etag');
  assert.match(first.headers.get('cache-control'), /max-age/);
  const again = await s.call('GET', '/registrations/1', { headers: { 'If-None-Match': tag } });
  assert.equal(again.status, 304);
  assert.equal(again.text, '');
  s.close();
});

test('a stale If-Match returns 412 and the ETag changes after a write', async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  const old = (await s.call('GET', '/registrations/1')).headers.get('etag');
  const ok = await s.call('PATCH', '/registrations/1', { body: { note: 'vegetarian' }, headers: { 'If-Match': old } });
  assert.equal(ok.status, 200);
  assert.notEqual(ok.headers.get('etag'), old);
  const stale = await s.call('PATCH', '/registrations/1', { body: { note: 'other' }, headers: { 'If-Match': old } });
  assert.equal(stale.status, 412);
  assert.equal((await s.call('GET', '/registrations/1')).json.note, 'vegetarian');
  s.close();
});

test('missing or empty token returns 401 with WWW-Authenticate', async () => {
  const s = await setup();
  for (const headers of [{}, { Authorization: 'Bearer ' }, { Authorization: 'Bearer' }]) {
    const r = await s.call('GET', '/registrations', { token: null, headers });
    assert.equal(r.status, 401);
    assert.match(r.headers.get('www-authenticate'), /Bearer/);
  }
  s.close();
});

test('unsupported Accept returns 406; XML is produced when asked', async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  assert.equal((await s.call('GET', '/registrations/1', { headers: { Accept: 'text/html' } })).status, 406);
  const xml = await s.call('GET', '/registrations/1', { headers: { Accept: 'application/xml' } });
  assert.equal(xml.status, 200);
  assert.equal(xml.headers.get('content-type'), 'application/xml; charset=utf-8');
  assert.match(xml.text, /<status>registered<\/status>/);
  const err = await s.call('GET', '/registrations/99', { headers: { Accept: 'application/xml' } });
  assert.match(err.headers.get('content-type'), /^application\/problem\+xml/);
  s.close();
});

test('OPTIONS lists the allowed methods and answers CORS preflight', async () => {
  const s = await setup();
  const r = await s.call('OPTIONS', '/registrations/1', { token: null });
  assert.equal(r.status, 204);
  for (const m of ['GET', 'PATCH', 'DELETE', 'OPTIONS']) assert.ok(r.headers.get('allow').includes(m));
  assert.ok(r.headers.get('access-control-allow-origin'));
  assert.match(r.headers.get('access-control-allow-headers'), /Idempotency-Key/);
  s.close();
});

test('X-HTTP-Method-Override works as a fallback for a POST', async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  const r = await s.call('POST', '/registrations/1', { body: { note: 'via override' }, headers: { 'X-HTTP-Method-Override': 'PATCH' } });
  assert.equal(r.status, 200);
  assert.equal(r.json.note, 'via override');
  s.close();
});

test('the rate limit is per client and sends Retry-After', async () => {
  const s = await setup({ rateLimit: 3 });
  const codes = [];
  for (let i = 0; i < 4; i += 1) codes.push((await s.call('GET', '/registrations')).status);
  assert.deepEqual(codes, [200, 200, 200, 429]);
  const r = await s.call('GET', '/registrations');
  assert.ok(Number(r.headers.get('retry-after')) >= 1);
  assert.equal(r.headers.get('x-ratelimit-remaining'), '0');
  const other = await s.call('GET', '/registrations', { token: 'student:other' });
  assert.equal(other.status, 200);
  assert.equal(other.headers.get('x-ratelimit-limit'), '3');
  s.close();
});

test('security and CORS headers are present; bodies are labelled with a charset', async () => {
  const s = await setup();
  const r = await s.call('GET', '/registrations');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(r.headers.get('strict-transport-security'));
  assert.equal(r.headers.get('content-type'), 'application/json; charset=utf-8');
  assert.ok(r.headers.get('access-control-allow-origin'));
  s.close();
});

test('large lists are gzip-compressed', async () => {
  const s = await setup({ event: makeEvent({ capacity: 500 }) });
  for (let i = 0; i < 12; i += 1) await s.call('POST', '/registrations', { body: GOOD, token: 'organizer:O', headers: {} }).catch(() => null);
  for (let i = 0; i < 12; i += 1) await s.call('POST', '/registrations', { body: GOOD, token: `student:S${i}` });
  const r = await s.call('GET', '/registrations?limit=50', { token: 'organizer:O', headers: { 'Accept-Encoding': 'gzip' } });
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('content-encoding'), 'gzip');
  assert.ok(JSON.parse(r.text).total >= 12);
  s.close();
});

// ---------------- Assignment 6: honest status codes and errors ----------------
test('400 for unreadable JSON, 422 for readable-but-wrong fields, 415 for the wrong Content-Type', async () => {
  const s = await setup();
  const bad = await s.call('POST', '/registrations', { raw: '{"event_id": [' });
  assert.equal(bad.status, 400);
  assert.ok(bad.json.type.endsWith('/malformed-body'));
  const wrongType = await s.call('POST', '/registrations', { raw: 'event_id=1', headers: { 'Content-Type': 'text/plain' } });
  assert.equal(wrongType.status, 415);
  const fields = await s.call('POST', '/registrations', { body: { event_id: 'one', phone: '12', note: 'x'.repeat(201) } });
  assert.equal(fields.status, 422);
  assert.deepEqual(fields.json.errors.map((e) => e.field).sort(), ['event_id', 'note', 'phone']);
  assert.deepEqual(Object.keys(fields.json).sort(), ['detail', 'errors', 'instance', 'status', 'title', 'type']);
  s.close();
});

test('unknown event -> 422, closed -> 422, full -> 422, duplicate -> 409', async () => {
  const s = await setup({ event: makeEvent({ capacity: 1 }) });
  const unknown = await s.call('POST', '/registrations', { body: { event_id: 77 } });
  assert.equal(unknown.status, 422);
  assert.ok(unknown.json.type.endsWith('/unknown-event'));
  const first = await s.call('POST', '/registrations', { body: GOOD });
  assert.equal(first.status, 201);
  const dup = await s.call('POST', '/registrations', { body: GOOD });
  assert.equal(dup.status, 409);
  assert.ok(dup.json.type.endsWith('/already-registered'));
  const full = await s.call('POST', '/registrations', { body: GOOD, token: 'student:21CS002' });
  assert.equal(full.status, 422);
  assert.ok(full.json.type.endsWith('/event-full'));
  s.close();
  const closed = await setup({ event: makeEvent({ registration_open: false }) });
  const r = await closed.call('POST', '/registrations', { body: GOOD });
  assert.equal(r.status, 422);
  assert.ok(r.json.type.endsWith('/event-closed'));
  closed.close();
});

test('cancel frees the seat; cancelling again is a 409; the student can register again', async () => {
  const s = await setup({ event: makeEvent({ capacity: 1 }) });
  await s.call('POST', '/registrations', { body: GOOD });
  assert.equal((await s.call('POST', '/registrations/1/cancellation')).json.status, 'cancelled');
  const again = await s.call('POST', '/registrations/1/cancellation');
  assert.equal(again.status, 409);
  assert.ok(again.json.type.endsWith('/illegal-transition'));
  assert.equal((await s.call('POST', '/registrations', { body: GOOD, token: 'student:21CS002' })).status, 201);   // the seat was free
  assert.equal((await s.call('DELETE', '/registrations/1')).status, 204);
  assert.equal((await s.call('GET', '/registrations/1')).status, 404);
  s.close();
});

test('attendance: students get 403, organizers check in once, attended cannot be cancelled', async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  const denied = await s.call('POST', '/registrations/1/attendance');
  assert.equal(denied.status, 403);
  const ok = await s.call('POST', '/registrations/1/attendance', { token: 'organizer:21CS010' });
  assert.equal(ok.status, 201);
  assert.equal(ok.json.status, 'attended');
  assert.ok(ok.json.checked_in_at);
  assert.equal((await s.call('POST', '/registrations/1/attendance', { token: 'organizer:21CS010' })).status, 409);
  assert.equal((await s.call('POST', '/registrations/1/cancellation')).status, 409);
  s.close();
});

test("a student never sees someone else's registration; organizers see all", async () => {
  const s = await setup();
  await s.call('POST', '/registrations', { body: GOOD });
  assert.equal((await s.call('GET', '/registrations/1', { token: 'student:21CS999' })).status, 404);
  assert.equal((await s.call('GET', '/registrations/1', { token: 'organizer:21CS010' })).status, 200);
  assert.equal((await s.call('GET', '/registrations', { token: 'student:21CS999' })).json.total, 0);
  s.close();
});

test('list filters, sorts and validates its query string', async () => {
  const s = await setup({ event: makeEvent({ capacity: 5 }) });
  for (const who of ['A', 'B', 'C']) await s.call('POST', '/registrations', { body: GOOD, token: `student:${who}` });
  await s.call('POST', '/registrations/2/cancellation', { token: 'student:B' });
  const r = await s.call('GET', '/registrations?event_id=1&status=cancelled&limit=5', { token: 'organizer:O' });
  assert.equal(r.json.total, 1);
  assert.equal(r.json.items[0].id, 2);
  const bad = await s.call('GET', '/registrations?limit=0&status=lost', { token: 'organizer:O' });
  assert.equal(bad.status, 422);
  assert.equal(bad.json.errors.length, 2);
  s.close();
});

// ---------------- D1-D3: dependencies and fallbacks ----------------
test('Events down -> 503 with Retry-After and no registration; the key is free for a retry', async () => {
  let up = false;
  const events = { async getEvent() { if (!up) throw new Error('connection refused'); return { found: true, event: makeEvent() }; } };
  const s = await setup({ events });
  const h = { 'Idempotency-Key': 'retry-me' };
  const r = await s.call('POST', '/registrations', { body: GOOD, headers: h });
  assert.equal(r.status, 503);
  assert.equal(r.headers.get('retry-after'), '5');
  assert.ok(r.json.type.endsWith('/events-unavailable'));
  up = true;
  assert.equal((await s.call('POST', '/registrations', { body: GOOD, headers: h })).status, 201);
  s.close();
});

test('Notifications down -> the registration still succeeds and shows notification: pending', async () => {
  const s = await setup({ notify: { async send() { throw new Error('gateway down'); } } });
  const r = await s.call('POST', '/registrations', { body: { event_id: 1, phone: '9876543210' } });
  assert.equal(r.status, 201);
  assert.equal(r.json.notification, 'pending');
  const sent = await setup();
  const ok = await sent.call('POST', '/registrations', { body: { event_id: 1, phone: '9876543210' } });
  assert.equal(ok.json.notification, 'sent');
  assert.equal(sent.calls.notify.length, 1);
  s.close(); sent.close();
});

test('a crash inside the service is hidden from the client', async () => {
  const events = { async getEvent() { return { found: true, event: makeEvent() }; } };
  const s = await setup({ events });
  const registrations = new MemoryRepo(T.registrations);
  registrations.insert = async () => { throw new Error('mysql password is hunter2'); };
  const app = createApp({ express, registrations, attendance: new MemoryRepo(T.attendance), eventsClient: events, notifier: { async send() {} }, log: silent });
  const { server, base } = await listen(app);
  const r = await api(base)('POST', '/registrations', { body: GOOD });
  assert.equal(r.status, 500);
  assert.ok(!r.text.includes('hunter2') && !r.text.includes('at '));
  assert.ok(r.json.type.endsWith('/internal-error'));
  server.close(); s.close();
});

test('same key with a different body is a 422', async () => {
  const s = await setup();
  const h = { 'Idempotency-Key': 'k1' };
  await s.call('POST', '/registrations', { body: GOOD, headers: h });
  const r = await s.call('POST', '/registrations', { body: { event_id: 1, note: 'different' }, headers: h });
  assert.equal(r.status, 422);
  assert.ok(r.json.type.endsWith('/idempotency-key-reuse'));
  s.close();
});

test('two students racing for the last seat: exactly one wins', async () => {
  const s = await setup({ event: makeEvent({ capacity: 1 }) });
  const [a, b] = await Promise.all([
    s.call('POST', '/registrations', { body: GOOD, token: 'student:A' }),
    s.call('POST', '/registrations', { body: GOOD, token: 'student:B' }),
  ]);
  assert.deepEqual([a.status, b.status].sort(), [201, 422]);
  s.close();
});
