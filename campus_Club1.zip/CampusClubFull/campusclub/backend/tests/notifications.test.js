'use strict';
// A3 in code: the SOAP adapter builds the envelope, parses the answer, and maps faults
// into OUR vocabulary so the partner's words never reach a student.
const test = require('node:test');
const assert = require('node:assert/strict');
const { express, listen, api } = require('./helpers');
const T = require('../lib/tables');
const { MemoryRepo } = require('../lib/repo');
const { createApp } = require('../services/notifications/app');
const sms = require('../services/notifications/smsGateway');

const quiet = { error() {} };

test('the request envelope has credentials in the Header and the call in the Body', () => {
  const xml = sms.buildEnvelope({ merchantId: 'M1', apiKey: 'K1', to: '9876543210', text: 'Hi & bye', ref: 'N1' });
  assert.match(xml, /<soap:Header>\s*<sms:AuthHeader>[\s\S]*<sms:merchantId>M1<\/sms:merchantId>/);
  assert.match(xml, /<soap:Body>\s*<sms:SendSmsRequest>[\s\S]*<sms:recipient>9876543210<\/sms:recipient>/);
  assert.match(xml, /Hi &amp; bye/);
});

test('fault mapping: partner words become CampusClub errors', () => {
  const map = (code) => sms.mapFault({ code, faultcode: 'soap:Client', message: 'x' });
  assert.equal(map('INVALID_NUMBER').key, 'recipient-unreachable');
  assert.equal(map('GATEWAY_UNAVAILABLE').key, 'notifications-unavailable');
  assert.equal(map('INSUFFICIENT_CREDITS').key, 'notifications-unavailable');
  assert.equal(map('AUTH_FAILED').key, 'upstream-error');
  assert.equal(map('SOMETHING_NEW').key, 'upstream-error');
});

test('the simulated gateway answers with a success envelope or a soap:Fault', () => {
  const ok = sms.parseResponse(sms.simulate(sms.buildEnvelope({ merchantId: 'M', apiKey: 'K', to: '9876543210', text: 't', ref: 'N5' })));
  assert.deepEqual([ok.ok, ok.messageId, ok.status], [true, 'GW-N5', 'ACCEPTED']);
  const bad = sms.parseResponse(sms.simulate(sms.buildEnvelope({ merchantId: 'M', apiKey: 'K', to: '9876540000', text: 't', ref: 'N6' })));
  assert.deepEqual([bad.ok, bad.faultcode, bad.code], [false, 'soap:Client', 'INVALID_NUMBER']);
});

async function setup() {
  const notifications = new MemoryRepo(T.notifications);
  const app = createApp({ express, notifications, gateway: sms.createGateway({ url: '', log: quiet }) });
  const { server, base } = await listen(app);
  return { call: api(base), close: () => server.close() };
}
const svc = 'service:registrations';
const body = (phone) => ({ recipient_ref: '21CS001', phone, message: 'You are registered.' });

test('POST /notifications: 201 sent, the phone number is masked, a repeat with the same key sends once', async () => {
  const s = await setup();
  const first = await s.call('POST', '/notifications', { token: svc, body: body('9876543210'), headers: { 'Idempotency-Key': 'reg-1' } });
  assert.equal(first.status, 201);
  assert.equal(first.json.status, 'sent');
  assert.ok(!first.text.includes('9876543210') && first.json.to.includes('*'));
  const again = await s.call('POST', '/notifications', { token: svc, body: body('9876543210'), headers: { 'Idempotency-Key': 'reg-1' } });
  assert.equal(again.json.id, first.json.id);
  assert.equal(again.headers.get('idempotent-replayed'), 'true');
  s.close();
});

test('invalid number -> 422 recipient-unreachable; gateway down -> 503 + Retry-After; students -> 403', async () => {
  const s = await setup();
  const bad = await s.call('POST', '/notifications', { token: svc, body: body('9876540000') });
  assert.equal(bad.status, 422);
  assert.ok(bad.json.type.endsWith('/recipient-unreachable'));
  assert.ok(!bad.text.includes('INVALID_NUMBER') && !bad.text.includes('soap'));
  const down = await s.call('POST', '/notifications', { token: svc, body: body('9876549999') });
  assert.equal(down.status, 503);
  assert.ok(down.headers.get('retry-after'));
  assert.equal((await s.call('POST', '/notifications', { token: 'student:21CS001', body: body('9876543210') })).status, 403);
  assert.equal((await s.call('POST', '/notifications', { token: svc, body: { phone: '1' } })).status, 422);
  s.close();
});
