'use strict';
// D2: timeout / retry / backoff rules of the outbound call between services.
const test = require('node:test');
const assert = require('node:assert/strict');
const { callService, Unavailable, backoff } = require('../lib/client');

const reply = (status, body = {}) => ({ status, text: async () => JSON.stringify(body) });
function script(outcomes) {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, opts });
    const o = outcomes[Math.min(calls.length - 1, outcomes.length - 1)];
    if (o instanceof Error) throw o;
    return o;
  };
  return { calls, fetchImpl };
}
const base = { baseUrl: 'http://events.invalid', path: '/events/1', sleep: async () => {} };

test('retries transient failures, then succeeds', async () => {
  const s = script([new Error('timed out'), reply(503), reply(200, { id: 1 })]);
  const r = await callService({ ...base, fetchImpl: s.fetchImpl });
  assert.equal(r.status, 200);
  assert.equal(s.calls.length, 3);
});

test('a 4xx is never retried', async () => {
  const s = script([reply(404)]);
  const r = await callService({ ...base, fetchImpl: s.fetchImpl });
  assert.equal(r.status, 404);
  assert.equal(s.calls.length, 1);
});

test('gives up after all attempts with Unavailable', async () => {
  const s = script([new Error('refused')]);
  await assert.rejects(callService({ ...base, fetchImpl: s.fetchImpl }), Unavailable);
  assert.equal(s.calls.length, 3);
});

test('a POST is retried only when it carries an Idempotency-Key, and the key is sent every time', async () => {
  const plain = script([reply(503)]);
  await assert.rejects(callService({ ...base, method: 'POST', body: {}, fetchImpl: plain.fetchImpl }), Unavailable);
  assert.equal(plain.calls.length, 1);
  const keyed = script([reply(503), reply(201)]);
  const r = await callService({ ...base, method: 'POST', body: {}, idempotencyKey: 'k-1', fetchImpl: keyed.fetchImpl });
  assert.equal(r.status, 201);
  assert.equal(keyed.calls.length, 2);
  assert.ok(keyed.calls.every((c) => c.opts.headers['Idempotency-Key'] === 'k-1'));
});

test('every attempt has a timeout signal; the address must be configured', async () => {
  const s = script([reply(200)]);
  await callService({ ...base, fetchImpl: s.fetchImpl });
  assert.ok(s.calls[0].opts.signal);
  await assert.rejects(callService({ path: '/x', fetchImpl: s.fetchImpl }), Unavailable);
});

test('backoff grows exponentially and is capped (full jitter)', () => {
  for (const [attempt, ceiling] of [[0, 200], [1, 400], [2, 800], [10, 2000]]) {
    for (let i = 0; i < 50; i += 1) { const b = backoff(attempt); assert.ok(b >= 0 && b <= ceiling); }
  }
});
