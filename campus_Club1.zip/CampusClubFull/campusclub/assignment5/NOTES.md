# CS 543 - Assignment 5 - NOTES (CampusClub)

<!--TEAM-->
**Team ID:** TEAM-00

| Roll No | Name |
|---|---|
| ROLL-1 | Member One |
| ROLL-2 | Member Two |
| ROLL-3 | Member Three |
| ROLL-4 | Member Four |
<!--/TEAM-->

Service: Registrations (same service as Assignment 4, updated). Code: `backend/services/registrations/`. Shared HTTP code: `backend/lib/http.js`.

---

## A1. CampusClub method map

| Action | Method + URL |
|---|---|
| Register for an event | `POST /registrations` |
| List registrations (filter/sort/page) | `GET /registrations?event_id=1&status=registered&sort=-created_at&limit=5&offset=0` |
| Read one registration | `GET /registrations/{id}` |
| Change the note | `PATCH /registrations/{id}` |
| Remove a cancelled registration | `DELETE /registrations/{id}` |
| Cancel a registration | `POST /registrations/{id}/cancellation` |
| Check a student in | `POST /registrations/{id}/attendance` |
| Which methods are allowed? | `OPTIONS /registrations` and `OPTIONS /registrations/{id}` |

Non-CRUD actions (cancel, check in) are POSTs to sub-resources; no verb is in any URL. `X-HTTP-Method-Override` is accepted only as a documented
fallback: a `POST` carrying `X-HTTP-Method-Override: PATCH|PUT|DELETE` is treated as that method.

## A3. Safe and idempotent

| Endpoint | Safe | Idempotent | Note |
|---|---|---|---|
| GET `/registrations`, GET `/registrations/{id}`, OPTIONS | yes | yes | naturally retry-safe |
| POST `/registrations` | no | **no** | a repeat would take a second seat |
| PATCH `/registrations/{id}` | no | yes | sets the note to a value; repeat = same state |
| DELETE `/registrations/{id}` | no | yes | repeat gives 404 but the state is the same |
| POST `.../cancellation` | no | yes (in effect) | repeat gives 409, state unchanged |
| POST `.../attendance` | no | yes (in effect) | repeat gives 409, state unchanged |

No GET changes state.

## D2. Headers table

| Endpoint | Request headers it needs | Response headers it sets |
|---|---|---|
| POST `/registrations` | `Authorization`, `Content-Type: application/json`, `Accept`, `Idempotency-Key` | `Location`, `ETag`, `Content-Type`, `Cache-Control: no-store`, `Idempotent-Replayed` (replay) |
| GET `/registrations` | `Authorization`, `Accept`, `Accept-Encoding` | `Content-Type`, `Cache-Control: no-store`, `Content-Encoding: gzip` (large bodies), `Vary` |
| GET `/registrations/{id}` | `Authorization`, `Accept`, `If-None-Match` | `ETag`, `Cache-Control: private, max-age=30, must-revalidate`, `Content-Type`; 304 has no body |
| PATCH `/registrations/{id}` | `Authorization`, `Content-Type`, `If-Match` (optional) | `ETag` (new), `Content-Type` |
| DELETE `/registrations/{id}` | `Authorization` | 204, no body |
| POST `.../cancellation` | `Authorization` | `ETag`, `Content-Type` |
| POST `.../attendance` | `Authorization` (organizer or admin) | `Location`, `ETag`, `Content-Type` |
| OPTIONS (both) | `Origin`, `Access-Control-Request-*` (preflight) | `Allow`, `Access-Control-Allow-Methods`, `Access-Control-Allow-Headers`, `Access-Control-Max-Age` |
| **Every response** | `Authorization: Bearer <role>:<id>` (401 if missing/empty) | `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-Content-Type-Options: nosniff`, `Strict-Transport-Security`, `Access-Control-Allow-Origin`, `Vary`, `X-Request-ID`, `Date`; 429 adds `Retry-After`; errors use `Content-Type: application/problem+json` |

The service is served over HTTPS in production (HSTS tells browsers to insist on it).

## C4. Safe-retry plan

| Risky endpoint | Mechanism | Why |
|---|---|---|
| POST `/registrations` | `Idempotency-Key` | neither safe nor idempotent: a duplicate would take a second seat (and send a second SMS); the key returns the original registration |
| PATCH `/registrations/{id}` | `If-Match` | two editors cannot overwrite each other (412) |
| GET `/registrations/{id}` | `If-None-Match` | a repeat read costs nothing; 304 saves the body |
| DELETE, cancellation, attendance | none needed | idempotent in effect (the state machine answers 409 on a repeat) |

## A6. One complete exchange (HTTP/1.1)

**Request line + Host + headers**
```
POST /registrations HTTP/1.1
Host: 127.0.0.1:4003
Content-Type: application/json
Authorization: Bearer student:21CS001
Idempotency-Key: demo-key-001
```
**Request body**
```json
{"event_id":1,"phone":"9876543210","note":"Vegetarian"}
```
**Status line + response headers**
```
HTTP/1.1 201 Created
Content-Type: application/json; charset=utf-8
Location: /registrations/1
ETag: "3e774731d33d9224"
Cache-Control: no-store
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
X-Content-Type-Options: nosniff
Strict-Transport-Security: max-age=31536000; includeSubDomains
Access-Control-Allow-Origin: *
```
**Response body**
```json
{"id":1,"event_id":1,"student":"21CS001","status":"registered","ticket_code":"5DA9CBFA","note":"Vegetarian","notification":"sent","checked_in_at":null,"links":{"self":"/registrations/1","cancellation":"/registrations/1/cancellation","attendance":"/registrations/1/attendance"}}
```
(Replace this with the exact exchange from *your* `curl-transcript.txt`; your ETag, ticket code and dates will differ.)

---

## Answers

**1. Three endpoints, method, status, key header.**
* `POST /registrations` - 201 - **`Location`**: tells the client the URL of the new registration, so it can find it again without guessing.
* `GET /registrations/{id}` - 200 - **`ETag`**: lets the client revalidate cheaply (304) and send `If-Match` later.
* `POST /registrations/{id}/attendance` - 201 - **`Location`**: points at the new attendance record created by the check-in.

**2. Safe / idempotent / neither.**
Safe: GET, HEAD, OPTIONS. Idempotent: those plus PATCH, DELETE and the POST sub-resources (cancellation, attendance: a repeat gets 409 and the state does not change).
Neither: `POST /registrations`, made retry-safe with `Idempotency-Key`: the same key with the same body returns the original registration, takes one seat, and sends one SMS.

**3. ETag, 304, 412.**
ETag: `"3e774731d33d9224"` (from `GET /registrations/1`; replace with yours).
304: `GET /registrations/1` with `If-None-Match: "3e774731d33d9224"` returns `304 Not Modified` with no body: it **saves** re-sending the body.
412: after a `PATCH` changed the registration (new ETag), another `PATCH` that still sends `If-Match: "3e774731d33d9224"` returns `412 Precondition Failed`:
it **prevents** the second editor from silently overwriting the first one's change (lost update).

**4. 422 vs 400.**
400: `POST /registrations` with body `{"event_id": [` (not parseable JSON): the server cannot even read the request.
422: `POST /registrations` with `{"event_id": 0}`: valid JSON, but the value breaks a rule. 400 means "I can't parse this"; 422 means "I understood it and refuse it".

**5. Blocked in the browser but 200 in the server log.**
The **browser** blocked it (same-origin policy): the server answered normally, the browser then refused to hand the response to the page (for example the React app on
`http://localhost:5173` calling a service on port 4003 directly). The fix is the response header **`Access-Control-Allow-Origin`** naming the page's origin (or `*`), plus
answering the `OPTIONS` preflight (the services do both; the Vite dev proxy also avoids the problem).

**6. Cache-Control.**
Allows caching: `GET /registrations/{id}` returns `private, max-age=30, must-revalidate`: the user's own browser may reuse it briefly and must revalidate with the ETag afterwards.
`no-store`: `POST /registrations`, `GET /registrations` and every error response: they hold personal data (who registered for what) or one-time results and must not be kept by any cache.

**7. GET vs POST for search.**
POST is right when the criteria are too big for a URL (for example hundreds of ids) or are sensitive and must not appear in URLs, logs or browser history. What you give up: it is no
longer safe/idempotent by definition, so it is not cacheable, not bookmarkable or shareable, and clients and proxies will not retry it automatically.

**8. Location.**
On a `201` it points to the **newly created resource** (`/registrations/1`). On a `3xx` it points to the **place the client should go next** (the new address of a moved resource, or the page to GET after a 303).
This service only sends `Location` on 201.

---

## Evidence (generated by `npm run evidence:a5` in `backend/`)

* `curl-transcript.txt` (curl -v): create (201), idempotent repeat, 304, 412, and 400 / 404 / 401
* `test-output.txt`, `validator-output.txt`
