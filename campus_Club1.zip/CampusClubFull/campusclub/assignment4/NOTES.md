# CS 543 - Assignment 4 - NOTES (CampusClub)

<!--TEAM-->
**Team ID:** TEAM-00

| Roll No | Name |
|---|---|
| ROLL-1 | Member One |
| ROLL-2 | Member Two |
| ROLL-3 | Member Three |
| ROLL-4 | Member Four |
<!--/TEAM-->

**Service chosen:** Registrations (REST rebuild). Code: `backend/services/registrations/` (`openapi.yaml`, `app.js`, `models.js`) and tests in `backend/tests/`.
Stack: Node.js + Express, data in MySQL (table `registrations` and `attendance`, owned only by this service).

---

## A2. The operations as SOAP (starting point)

`registerForEvent(event, phone, note)`, `getRegistration(id)`, `listRegistrations(filter)`,
`cancelRegistration(id)`, `checkIn(id)`.

## A4. Resource table

| Method | URL | What it does | Success | Failures |
|---|---|---|---|---|
| POST | `/registrations` | Register for an event (Idempotency-Key supported) | 201 + `Location` | 400, 401, 409, 415, 422, 429, 503 |
| GET | `/registrations?event_id=&status=&sort=&limit=&offset=` | Filtered, sorted, paged list (students: their own) | 200 | 401, 422, 429 |
| GET | `/registrations/{id}` | Read one registration | 200 | 401, 404 |
| PATCH | `/registrations/{id}` | Change the note (only while registered) | 200 | 400, 401, 404, 409, 412, 415, 422 |
| DELETE | `/registrations/{id}` | Remove a cancelled registration | 204 | 401, 404, 409 |
| POST | `/registrations/{id}/cancellation` | Cancel (sub-resource) | 200 | 401, 404, 409 |
| POST | `/registrations/{id}/attendance` | Check the student in (sub-resource, organizers only) | 201 + `Location` | 401, 403, 404, 409 |

Nouns: **registrations**, **cancellation**, **attendance**. No verb (register, cancel, check) appears in any URL.

## A5. The hardest choice

`checkIn` mapped worst. It is not a plain create, replace or delete of the registration: the registration stays, its
status moves from registered to attended, and a record of who checked whom in and when must be kept. I rejected
`PATCH /registrations/42 {"status": "attended"}` (it would let any caller write any status, including one a student
could use on themselves) and `PUT` (it replaces the whole record). I chose `POST /registrations/42/attendance`: the
attendance is a thing that comes into existence (it has its own table and timestamp), only organizers may create it (403
otherwise), the server keeps control of the state machine, and a wrong-state attempt gets a clean 409. `cancelRegistration`
got the same treatment as `/cancellation`.

## D3. Fallback when a dependency is unreachable

Registrations makes two outbound calls, and I chose differently for each, on purpose.
* **Events (needed to register): FAIL.** The service returns `503 events-unavailable` with `Retry-After: 5`, and no registration is created.
  Degrading (saving the registration without knowing the capacity or whether the event is still open) would have been wrong,
  because it could sell seats that do not exist and register students for a cancelled event. The Idempotency-Key is released, so the retry is a normal attempt.
* **Notifications (confirmation SMS): DEGRADE.** The registration stands and the response shows `notification: "pending"` (or `"failed"`
  for a bad number). A missed text is an inconvenience, but refusing a valid registration because an SMS provider is down would punish the student for a failure they cannot fix.

## Answers

**1. WSDL vs openapi.yaml lines.**
`assignment3/partner.wsdl`: 104 lines. `openapi.yaml`: 426 lines (both counted with `find /c /v "" <file>`).
The difference is made of what REST has to say that one SOAP operation did not: seven operations instead of one, every failure status
documented per operation, the shared `Problem` schema, reusable headers and parameters. Two things the WSDL declared that OpenAPI does not need:
(1) the `binding` section (SOAP over HTTP, `soapAction`, style/use), because HTTP is itself the binding and the method + URL say what to do;
(2) the `message`/`part` indirection between `portType` and the types, because request and response bodies are referenced directly with `$ref`.

**2. A soap:Fault and its replacement.**
From `assignment3/soap-fault.xml`: `faultcode` = `soap:Client`, `faultstring` = "The recipient number is not valid", with `detail` carrying `SmsFault` / `INVALID_NUMBER`.

Replaced (by the Notifications service) with `422 Unprocessable Entity`, `Content-Type: application/problem+json`:

```json
{"type": "https://campusclub.example/problems/recipient-unreachable", "title": "Recipient cannot be reached",
 "status": 422, "detail": "The phone number could not receive the message.", "instance": "/notifications"}
```

A failure inside a `200 OK` is a problem for the network in between because proxies, caches, load balancers, retry libraries and monitoring
all decide using the status line: a 200 can be cached and replayed, is never retried or alerted on, and shows as "healthy" on dashboards,
while a real status code lets them tell a permanent refusal (422) from a transient fault (503).

**3. UDDI's publish / find / bind.**
*Publish* still exists, as publishing `openapi.yaml` (in the repository / an API portal). *Bind* still exists, but it is now just reading the address
from an environment variable (`EVENTS_URL`, `NOTIFICATIONS_URL`) and making an HTTP call with `callService`, with no generated stub. *Find* as a runtime step
disappeared: developers find the contract in the docs, and the running service finds its partner through configuration (environment variable, DNS,
or an API gateway in production). The OpenAPI file plus configuration took over the job of the registry.

**4. Who checks the request now.**
`validate()` in `models.js` (called first in the `POST /registrations` handler). Without it, a body like
`{"event_id": 1, "status": "attended"}` would get through and a student could mark themselves as having attended; `{"event_id": "1"}` or
`{"event_id": -5}` would reach the Events lookup with nonsense, and a 5 000-character `note` would be stored.

**5. Where I would still choose SOAP.**
The outbound SMS call to the gateway (which is SOAP in this design). The guarantee I would be buying is **message-level security**: WS-Security
signs the message and its credentials themselves, so they stay protected across every intermediary (gateway, queue, partner proxy) while TLS only
protects one hop at a time; plus a strictly enforced, machine-checked contract (WSDL + XSD) before any message is sent. The price is heavier tooling
and bigger messages. Everywhere else (clubs, events, registrations) REST is enough, because HTTP caching, status codes and idempotency keys give what those operations need.

---

## Evidence (generated by `npm run evidence:a4` in `backend/`)

* `curl-transcript.txt` (curl -i): create (201 + Location), same Idempotency-Key repeat, 400, 404, 409, and more
* `test-output.txt`: `node --test` result, all tests passed
* `validator-output.txt`: OpenAPI validator output, zero errors
