# CampusEats — REST API (Assignment 8)

**Selected service:** Menu / Catalogue  
**Technology:** Node.js, Express, HTML, CSS and browser `fetch()`  
**Data source:** In-memory JavaScript array (as required by the assignment).

## Run the project

1. Install Node.js (LTS).
2. Open a terminal in this `assignment8` folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:4008` in your browser.

On Windows, you can also double-click `RUN.bat`. On macOS/Linux, run `bash RUN.sh`.

## REST API routes

| Method | Path | Purpose | Success / error status |
|---|---|---|---|
| GET | `/items` | Get the complete menu list | 200 |
| GET | `/items/:id` | Get one item by its ID | 200; 404 if absent |
| POST | `/items` | Create a new menu item | 201; 422 if input is invalid |

### Example requests

Get all items:
```bash
curl -i http://localhost:4008/items
```

Get one item:
```bash
curl -i http://localhost:4008/items/1
```

Try an ID that does not exist:
```bash
curl -i http://localhost:4008/items/999
```

Create a menu item:
```bash
curl -i -X POST http://localhost:4008/items ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Veg Sandwich\",\"price\":75,\"available\":true}"
```

A successful POST returns HTTP **201 Created** and the newly created item as JSON. A missing/blank name or invalid price returns HTTP **422 Unprocessable Content**. A valid but unknown item ID returns HTTP **404 Not Found**.

## Answers for the assignment README questions

1. **Which CampusEats service did you pick, and what are its routes (method + path)?**  
   We picked the Menu / Catalogue service. Its routes are `GET /items`, `GET /items/:id`, and `POST /items`.

2. **Which status codes did you return, and for which outcomes (200 / 201 / 404 / 422)?**  
   `200` means a GET request was successful. `201` means a new menu item was created successfully. `404` means the requested item ID does not exist. `422` means the POST data is invalid, such as a missing dish name or an invalid price.

3. **Where did you use `req.params` and where `req.body`? Why does POST need `express.json()`?**  
   We used `req.params.id` in `GET /items/:id` to read the item ID from the URL. We used `req.body` in `POST /items` to read the new item's name, price and availability from the JSON request body. `express.json()` parses incoming JSON data and makes it available in `req.body`. Without this middleware, Express will not automatically read the JSON POST body.

## Submission evidence to add before submitting

- Add your team members' names and roll numbers below.
- Capture `screenshots/before.png` showing the four seed items before adding a dish.
- Capture `screenshots/after.png` showing the new dish after the POST request.
- Record a short demo: open the page, show the list, add one dish, and show the refreshed list.
- Upload the demo video to Google Drive and paste its share link here.

**Team members:** Add names and roll numbers here.  
**Demo video:** Add Google Drive share link here.
