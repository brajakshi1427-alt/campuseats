const menuList = document.getElementById('menu-list');
const listMessage = document.getElementById('list-message');
const formMessage = document.getElementById('form-message');
const form = document.getElementById('item-form');

function showMessage(element, message, type = '') {
  element.textContent = message;
  element.className = `message ${type}`.trim();
}

function renderItems(items) {
  menuList.replaceChildren();
  document.getElementById('total-count').textContent = items.length;
  document.getElementById('available-count').textContent = items.filter(item => item.available).length;

  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = 'No menu items found. Add the first dish using the form.';
    menuList.appendChild(empty);
    return;
  }

  items.forEach(item => {
    const card = document.createElement('article');
    card.className = 'menu-item';
    const details = document.createElement('div');
    const name = document.createElement('p');
    name.className = 'item-name';
    name.textContent = item.name;
    const meta = document.createElement('p');
    meta.className = 'item-meta';
    meta.textContent = `Menu item #${item.id}`;
    const status = document.createElement('span');
    status.className = `availability${item.available ? '' : ' off'}`;
    status.textContent = item.available ? 'Available' : 'Currently unavailable';
    details.append(name, meta, status);
    const price = document.createElement('span');
    price.className = 'item-price';
    price.textContent = `₹${Number(item.price).toFixed(2).replace(/\.00$/, '')}`;
    card.append(details, price);
    menuList.appendChild(card);
  });
}

async function loadItems() {
  showMessage(listMessage, 'Loading menu…');
  try {
    const response = await fetch('/items');
    if (!response.ok) throw new Error(`Could not load menu (HTTP ${response.status}).`);
    const items = await response.json();
    renderItems(items);
    showMessage(listMessage, `Showing ${items.length} menu items.`, 'success');
  } catch (error) {
    showMessage(listMessage, error.message, 'error');
  }
}

document.getElementById('refresh-btn').addEventListener('click', loadItems);

form.addEventListener('submit', async event => {
  event.preventDefault();
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  showMessage(formMessage, 'Adding your dish…');
  const payload = {
    name: document.getElementById('name').value.trim(),
    price: Number(document.getElementById('price').value),
    available: document.getElementById('available').checked
  };

  try {
    const response = await fetch('/items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || result.error || `Request failed (HTTP ${response.status}).`);
    form.reset();
    document.getElementById('available').checked = true;
    showMessage(formMessage, `Added "${result.name}" successfully (HTTP 201).`, 'success');
    await loadItems();
  } catch (error) {
    showMessage(formMessage, error.message, 'error');
  } finally {
    submitButton.disabled = false;
  }
});

loadItems();
