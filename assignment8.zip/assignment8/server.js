'use strict';

const path = require('path');
const express = require('express');

const app = express();
const PORT = Number(process.env.PORT) || 4008;

// Assignment 8 asks for an in-memory array as the source of truth.
let items = [
  { id: 1, name: 'Masala Dosa', price: 60, available: true },
  { id: 2, name: 'Veg Burger', price: 80, available: true },
  { id: 3, name: 'Paneer Roll', price: 90, available: true },
  { id: 4, name: 'Cold Coffee', price: 50, available: false }
];
let nextId = Math.max(...items.map(item => item.id)) + 1;

app.disable('x-powered-by');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// GET /items — return the complete menu.
app.get('/items', (req, res) => {
  res.status(200).json(items);
});

// GET /items/:id — return one menu item, or 404 when it does not exist.
app.get('/items/:id', (req, res) => {
  const id = Number(req.params.id);
  const item = Number.isInteger(id) && id > 0
    ? items.find(entry => entry.id === id)
    : undefined;

  if (!item) {
    return res.status(404).json({ error: 'Item not found', id: req.params.id });
  }
  return res.status(200).json(item);
});

// POST /items — validate and create a new menu item.
app.post('/items', (req, res) => {
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const price = Number(body.price);

  if (!name) {
    return res.status(422).json({ error: 'Validation failed', message: 'name is required and cannot be empty.' });
  }
  if (body.price === undefined || body.price === null || body.price === '' ||
      !Number.isFinite(price) || price <= 0) {
    return res.status(422).json({ error: 'Validation failed', message: 'price must be a positive number.' });
  }
  if (body.available !== undefined && typeof body.available !== 'boolean') {
    return res.status(422).json({ error: 'Validation failed', message: 'available must be true or false.' });
  }

  const newItem = {
    id: nextId++,
    name,
    price,
    available: body.available === undefined ? true : body.available
  };
  items.push(newItem);
  return res.status(201).json(newItem);
});

// Return a clear JSON error if the client sends malformed JSON.
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ error: 'Bad Request', message: 'Request body must contain valid JSON.' });
  }
  console.error(err);
  return res.status(500).json({ error: 'Internal Server Error' });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`CampusEats Assignment 8 REST API running at http://localhost:${PORT}`);
    console.log(`Try GET http://localhost:${PORT}/items`);
  });
}

module.exports = app;
